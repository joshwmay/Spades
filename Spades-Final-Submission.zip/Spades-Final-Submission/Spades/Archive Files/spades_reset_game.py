import random
import time
import sys

def reset_desk():
    answer = input("Restart?")
    if answer == "Yes":
        print "Starting new game"
    else:
		print "Thanks for playing!"
    sys.exit(0)

if __name__ == "__main__":
    answer = input("Restart?")
    if answer.lower().strip() in "Yes".split():
        reset_desk()

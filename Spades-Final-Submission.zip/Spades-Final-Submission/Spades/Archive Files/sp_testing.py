from spades_functions import *
from spades_cards import Cards
from spades_discard import Discard
from spades_rules import Rules
from spades_gui import Ui_MainWindow
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QComboBox, QPushButton, QTableWidgetItem
import time
import sys

def test():
    tc = Cards()
    td = Discard()
    tr = Rules()
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    ui.display_card_all(tc)
    tc.p1_bid = ui.bid_input()
    ui.update_table_bid(tc)

    wrap = td.player_disc(tc.turn[0], 1, tc.spades_break)
    if tc.turn[0] == 1:
        print("You should discard:", wrap[1])
        ui.takingturn()
        print("Finished Turn")
        print("suit is set to", tc.set_suit)

    if tc.turn[0] == 2:
        tc.p2 = wrap[0]
        tc.p2disc = wrap[1]
        tc.spades_break = wrap[2]
        tc.p2_discs = wrap[3]
        tc.set_suit = wrap[4]
        ui.p2_disc(tc.p2disc)

    if tc.turn[0] == 3:
        tc.p3 = wrap[0]
        tc.p3disc = wrap[1]
        tc.spades_break = wrap[2]
        tc.p3_discs = wrap[3]
        tc.set_suit = wrap[4]
        ui.p3_disc(tc.p3disc)

    if tc.turn[0] == 4:
        tc.p4 = wrap[0]
        tc.p4disc = wrap[1]
        tc.spades_break = wrap[2]
        tc.p4_discs = wrap[3]
        tc.set_suit = wrap[4]
        ui.p4_disc(tc.p4disc)

    wrap = td.player_disc(tc.turn[1], 2, tc.spades_break)
    if tc.turn[1] == 1:
        print("You should discard:", wrap[1])
        ui.takingturn()
        print("Finished Turn")
    if tc.turn[1] == 2:
        tc.p2 = wrap[0]
        tc.p2disc = wrap[1]
        tc.spades_break = wrap[2]
        tc.p2_discs = wrap[3]
        tc.set_suit = wrap[4]
        ui.p2_disc(tc.p2disc)
    if tc.turn[1] == 3:
        tc.p3 = wrap[0]
        tc.p3disc = wrap[1]
        tc.spades_break = wrap[2]
        tc.p3_discs = wrap[3]
        tc.set_suit = wrap[4]
        ui.p3_disc(tc.p3disc)
    if tc.turn[1] == 4:
        tc.p4 = wrap[0]
        tc.p4disc = wrap[1]
        tc.spades_break = wrap[2]
        tc.p4_discs = wrap[3]
        tc.set_suit = wrap[4]
        ui.p4_disc(tc.p4disc)

    wrap = td.player_disc(tc.turn[2], 3, tc.spades_break)
    if tc.turn[2] == 1:
        print("You should discard:", wrap[1])
        ui.takingturn()
        print("Finished Turn")
    if tc.turn[2] == 2:
        tc.p2 = wrap[0]
        tc.p2disc = wrap[1]
        tc.spades_break = wrap[2]
        tc.p2_discs = wrap[3]
        tc.set_suit = wrap[4]
        ui.p2_disc(tc.p2disc)
    if tc.turn[2] == 3:
        tc.p3 = wrap[0]
        tc.p3disc = wrap[1]
        tc.spades_break = wrap[2]
        tc.p3_discs = wrap[3]
        tc.set_suit = wrap[4]
        ui.p3_disc(tc.p3disc)
    if tc.turn[2] == 4:
        tc.p4 = wrap[0]
        tc.p4disc = wrap[1]
        tc.spades_break = wrap[2]
        tc.p4_discs = wrap[3]
        tc.set_suit = wrap[4]
        ui.p4_disc(tc.p4disc)

    wrap = td.player_disc(tc.turn[3], 4, tc.spades_break)
    if tc.turn[3] == 1:
        print("You should discard:", wrap[1])
        ui.takingturn()
        print("Finished Turn")
    if tc.turn[3] == 2:
        tc.p2 = wrap[0]
        tc.p2disc = wrap[1]
        tc.spades_break = wrap[2]
        tc.p2_discs = wrap[3]
        tc.set_suit = wrap[4]
        ui.p2_disc(tc.p2disc)
    if tc.turn[3] == 3:
        tc.p3 = wrap[0]
        tc.p3disc = wrap[1]
        tc.spades_break = wrap[2]
        tc.p3_discs = wrap[3]
        tc.set_suit = wrap[4]
        ui.p3_disc(tc.p3disc)
    if tc.turn[3] == 4:
        tc.p4 = wrap[0]
        tc.p4disc = wrap[1]
        tc.spades_break = wrap[2]
        tc.p4_discs = wrap[3]
        tc.set_suit = wrap[4]
        ui.p4_disc(tc.p4disc)

    print(tc.turn)
    print(tc.p1disc)
    print(tc.p2disc)
    print(tc.p3disc)
    print(tc.p4disc,"\n")
    print(tc.set_suit)
    winner = tr.winner_(tc.p1disc, tc.p2disc, tc.p3disc, tc.p4disc, tc.set_suit)
    ui.update_table_round(tc, winner[0], 1)
    print("Player ",winner[0]," wins!")
    print("Order for next round is \n",winner[1])
    sys.exit(app.exec_())

test()

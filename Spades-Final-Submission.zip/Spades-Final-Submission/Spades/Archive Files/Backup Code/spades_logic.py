def first_logic(player_hand, player_bid, mate_bid, spades_break):
    count_hearts = 0
    count_clubs = 0
    count_diamonds = 0
    count_spades = 0
    for i in player_hand:
        if "Hearts" in i:
            count_hearts = count_hearts + 1
        if "Clubs" in i:
            count_clubs = count_clubs + 1
        if "Diamonds" in i:
            count_diamonds = count_diamonds + 1
        if "Spades" in i:
            count_spades = count_spades + 1
    if player_bid > 0 and spades_break is True:
        if (13,"Ace","Hearts") in player_hand:
            discard = (13, "Ace", "Hearts")
            player_hand.remove(discard)
            return player_hand, discard
        if (26,"Ace","Clubs") in player_hand:
            discard = (26, "Ace", "Clubs")
            player_hand.remove(discard)
            return player_hand, discard
        if (39, "Ace", "Diamonds") in player_hand:
            discard = (39, "Ace", "Diamonds")
            player_hand.remove(discard)
            return player_hand, discard
        if (12,"King","Hearts") in player_hand:
            discard = (12, "King", "Hearts")
            player_hand.remove(discard)
            return player_hand, discard
        if (25,"King","Clubs") in player_hand:
            discard = (25, "King", "Clubs")
            player_hand.remove(discard)
            return player_hand, discard
        if (38, "King", "Diamonds") in player_hand:
            discard = (38, "King", "Diamonds")
            player_hand.remove(discard)
            return player_hand, discard
        if mate_bid > 0:
            discard = min(player_hand)
            player_hand.remove(discard)
            return player_hand, discard
    if player_bid == 0 and spades_break is True:
        if count_hearts > count_clubs and count_hearts > count_diamonds:
            discard = min(player_hand)
            player_hand.remove(discard)
            return player_hand, discard
        if count_clubs > count_hearts and count_clubs > count_diamonds:
            for i in player_hand:
                if i[2] == "Clubs":
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard
        if count_diamonds > count_clubs and count_diamonds > count_hearts:
            for i in player_hand:
                if i[2] == "Diamonds":
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard
        else:
            discard
def second_logic(player_hand, player_bid, mate_bid, last_discard, spades_break):
        count_hearts = 0
        count_clubs = 0
        count_diamonds = 0
        count_spades = 0
        last_discard_key = last_discard[0]
        for i in player_hand:
            if "Hearts" in i:
                count_hearts = count_hearts + 1
            if "Clubs" in i:
                count_clubs = count_clubs + 1
            if "Diamonds" in i:
                count_diamonds = count_diamonds + 1
            if "Spades" in i:
                count_spades = count_spades + 1
        if "Hearts" in last_discard:
            if player_bid == 0:
                if count_hearts > 0:
                    for i in sorted(player_hand, reverse=True):
                        if i[0] < last_discard_key and i[0] in range(1,13):
                            discard = i
                            player_hand.remove(discard)

                            return player_hand, discard

                if count_hearts == 0:
                    for i in sorted(player_hand, reverse=True):
                        if count_clubs < count_diamonds:
                            if i[0] in range(22,26):
                                discard = i
                                player_hand.remove(discard)

                                return player_hand, discard
                        if count_clubs > count_diamonds:
                            if i[0] in range(35,39):
                                discard = i
                                player_hand.remove(discard)

                                return player_hand, discard

            if player_bid > 0:
                for i in sorted(player_hand, reverse=True):
                    if "Hearts" in i:
                        discard = i
                        player_hand.remove(discard)

                        return player_hand, discard

                for card in player_hand:
                    if card[0] >= 40:
                        discard = card
                        player_hand.remove(discard)

                        return player_hand, discard
        if "Clubs" in last_discard:
            if player_bid == 0:
                if count_clubs > 0:
                    for i in sorted(player_hand, reverse=True):
                        if i[0] < last_discard_key and i[0] in range(14,26):
                            discard = i
                            player_hand.remove(discard)

                            return player_hand, discard

                if count_clubs == 0:
                    for i in sorted(player_hand, reverse=True):
                        if count_hearts < count_diamonds:
                            if i[0] in range(9,13):
                                discard = i
                                player_hand.remove(discard)

                                return player_hand, discard
                        if count_hearts > count_diamonds:
                            if i[0] in range(35,39):
                                discard = i
                                player_hand.remove(discard)

                                return player_hand, discard
            if player_bid > 0:
                for i in sorted(player_hand, reverse=True):
                    if "Clubs" in i:
                        discard = i
                        player_hand.remove(discard)

                        return player_hand, discard

                for card in player_hand:
                    if card[0] >= 40:
                        discard = card
                        player_hand.remove(discard)

                        return player_hand, discard
        if "Diamonds" in last_discard:
            if player_bid == 0:
                if count_diamonds > 0:
                    for i in sorted(player_hand, reverse=True):
                        if i[0] < last_discard_key  and i[0] in range(27,39):
                            discard = i
                            player_hand.remove(discard)

                            return player_hand, discard

                if count_diamonds == 0:
                    for i in sorted(player_hand, reverse=True):
                        if count_clubs < count_hearts:
                            if i[0] in range(22,26):
                                discard = i
                                player_hand.remove(discard)

                                return player_hand, discard
                        if count_clubs > count_hearts:
                            if i[0] in range(9, 13):
                                discard = i
                                player_hand.remove(discard)

            if player_bid > 0:
                for i in list(player_hand)[::-1]:
                    if "Hearts" in i:
                        discard = i
                        player_hand.remove(discard)

                        return player_hand, discard

                for card in player_hand:
                    if card[0] >= 40:
                        discard = card
                        player_hand.remove(discard)

                        return player_hand, discard

def third_logic(player_hand, player_bid, mate_bid, mate_discard, opp1_discard, spades_break):
    count_hearts = 0
    count_clubs = 0
    count_diamonds = 0
    count_spades = 0

    if mate_discard[2] == "Spades" and opp1_discard[2] != "Spades":
        top_card_key = mate_discard[0]
    if mate_discard[2] != "Spades" and opp1_discard[2] == "Spades":
        top_card_key = opp1_discard[0]
    if mate_discard[2] == opp1_discard[2] and mate_discard[0] > opp1_discard[0]:
        top_card_key = mate_discard[0]
    if mate_discard[2] == opp1_discard[2] and mate_discard[0] < opp1_discard[0]:
        top_card_key = opp1_discard[0]
    if mate_discard[2] != opp1_discard[2] and opp1_discard != "Spades":
        top_card_key = mate_discard[0]

    for i in player_hand:
        if "Hearts" in i:
            count_hearts = count_hearts + 1
        if "Clubs" in i:
            count_clubs = count_clubs + 1
        if "Diamonds" in i:
            count_diamonds = count_diamonds + 1
        if "Spades" in i:
            count_spades = count_spades + 1

    ###Beginning "Hearts" iteration
    if mate_discard[2] == "Hearts":
        if player_bid == 0:
            if count_hearts > 0:
                for i in sorted(player_hand, reverse=True):
                    if i[0] < top_card_key and i[2] == "Hearts":
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard
                for i in sorted(player_hand, reverse=True):
                    if i[0] in range(1,14):
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard

            if count_hearts == 0:
                for i in sorted(player_hand, reverse=True):
                    if count_clubs < count_diamonds:
                        if i[0] in range(21,27):
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard

                    if count_clubs > count_diamonds:
                        if i[0] in range(34,40):
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard
                    else:
                        if i[0] in range(1,39):
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard

        if mate_bid > 0:
            for i in sorted(player_hand, reverse=True):
                if (i[2] == "Hearts"
                    and top_card_key == mate_discard[0]
                    and i[0] < mate_discard[0]):
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard
                if (i[2] == "Hearts"
                    and top_card_key > mate_discard[0]
                    and i[0] > top_card_key):
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard
                if (i[2] == "Hearts"
                    and top_card_key > mate_discard[0]
                    and i[0] < top_card_key):
                    for v in player_hand:
                        if v[2] == "Hearts":
                            discard = v
                            player_hand.remove(discard)
                            return player_hand, discard

            if (mate_bid == 0
                and mate_discard[0] < top_card_key):
                for i in player_hand:
                    if "Hearts" in i:
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard

            if (mate_bid == 0
                and mate_discard[0] > top_card_key
                and mate_discard[2] == opp1_discard[2]):
                for i in sorted(player_hand, reverse=True):
                    if "Hearts" in i:
                        if i[0] > top_card_key:
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard
                for i in player_hand:
                    if "Hearts" in i:
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard

            for card in player_hand:
                if card[0] >= 40:
                    discard = card
                    player_hand.remove(discard)
                    return player_hand, discard

    ###Beginning "Clubs" iteration
    if "Clubs" in mate_discard:
        if player_bid == 0:
            if count_clubs > 0:
                for i in sorted(player_hand, reverse=True):
                    if i[0] < top_card_key and i[0] in range(14,27):
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard
                for i in sorted(player_hand, reverse=True):
                    if i[0] in range(1,14):
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard

            if count_clubs == 0:
                for i in sorted(player_hand, reverse=True):
                    if count_hearts < count_diamonds:
                        if i[0] in range(1,14):
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard

                    if count_hearts > count_diamonds:
                        if i[0] in range(27,40):
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard
                    else:
                        if i[0] in range(1,39):
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard

        if mate_bid > 0:
            for i in sorted(player_hand, reverse=True):
                if "Clubs" in i:
                    if (top_card_key == mate_discard[0]
                        and i[0] < mate_discard[0]):
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard
                    if (top_card_key > mate_discard[0]
                        and i[0] > top_card_key):
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard
                    if (top_card_key > mate_discard[0]
                        and i[0] < top_card_key):
                        for v in player_hand:
                            if "Clubs" in v:
                                discard = v
                                player_hand.remove(discard)
                                return player_hand, discard

        if (mate_bid == 0
            and mate_discard[0] < top_card_key):
            for i in player_hand:
                if "Clubs" in i:
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard

        if (mate_bid == 0
            and mate_discard[0] > top_card_key
            and mate_discard[2] == opp1_discard[2]):
            for i in sorted(player_hand, reverse=True):
                if "Clubs" in i:
                    if i[0] > top_card_key:
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard
            for i in player_hand:
                if "Clubs" in i:
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard

        for card in player_hand:
            if card[0] >= 40:
                discard = card
                player_hand.remove(discard)
                return player_hand, discard

    ###Beginning "Diamonds" iterration
    if "Diamonds" in mate_discard:
        if player_bid == 0 and count_diamonds > 0:
            for i in sorted(player_hand, reverse=True):
                if i[0] < top_card_key and i[2] == "Diamonds":
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard
            for i in sorted(player_hand, reverse=True):
                if i[0] in range(27,40):
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard

            if count_diamonds == 0:
                for i in sorted(player_hand, reverse=True):
                    if count_hearts < count_clubs:
                        if i[0] in range(1,14):
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard

                    if count_hearts > count_clubs:
                        if i[0] in range(14,27):
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard
                    else:
                        if i[0] in range(1,39):
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard

        if mate_bid > 0:
            for i in sorted(player_hand, reverse=True):
                if (i[2] == "Diamonds"
                    and top_card_key == mate_discard[0]
                    and i[0] < mate_discard[0]):
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard
                if (i[2] == "Diamonds"
                    and top_card_key > mate_discard[0]
                    and i[0] > top_card_key):
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard
                if (i[2] == "Diamonds"
                    and top_card_key > mate_discard[0]
                    and i[0] < top_card_key):
                    for v in player_hand:
                        # This is a reverse loop to pull the lowest "Diamond"
                        if v[2] == "Diamonds":
                            discard = v
                            player_hand.remove(discard)
                            return player_hand, discard

        if (mate_bid == 0
            and mate_discard[0] < top_card_key
            and mate_discard[2] == opp1_discard[2]):
            for i in player_hand:
                if "Diamonds" in i:
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard

        if (mate_bid == 0
            and mate_discard[0] > top_card_key
            and mate_discard[2] == opp1_discard[2]):
            for i in player_hand:
                if "Diamonds" in i and i[0] > top_card_key:
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard

            for i in player_hand:
                if "Diamonds" in i:
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard

        for card in player_hand:
            if card[0] >= 40:
                discard = card
                player_hand.remove(discard)
                return player_hand, discard

def fourth_logic(player_hand, player_bid, mate_bid, mate_discard, opp1_discard, opp2_discard, spades_break):
    count_hearts = 0
    count_clubs = 0
    count_diamonds = 0
    count_spades = 0
    suit = opp1_discard[2]
    if mate_discard[2] == "Spades" and opp1_discard[2] != "Spades" and opp2_discard[2] != "Spades":
        top_card_key = mate_discard[0]
    if mate_discard[2] != "Spades" and opp1_discard[2] == "Spades" or opp1_discard[2] != "Spades":
        if opp1_discard[2] == "Spades" and opp2_discard[2] != "Spades":
            top_card_key = opp1_discard[0]
        if opp1_discard[2] != "Spades" and opp2_discard[2] == "Spades":
            top_card_key = opp2_discard[0]
        else:
            if opp1_discard[0] > opp2_discard[0]:
                top_card_key = opp1_discard[0]
            if opp1_discard[0] < opp2_discard[0]:
                top_card_key = opp2_discard[0]
    if mate_discard[2] == suit and opp2_discard[2] == suit and mate_discard[0] < opp2_discard[0] and opp1_discard[0] < opp2_discard[0]:
        top_card_key = opp2_discard[0]
    if mate_discard[2] == suit and opp2_discard[2] == suit and mate_discard[0] < opp1_discard[0] and opp2_discard[0] < opp1_discard[0]:
        top_card_key = opp1_discard[0]
    if mate_discard[2] == suit and opp2_discard[2] == suit and opp1_discard[0] < mate_discard[0] and opp2_discard[0] < mate_discard[0]:
        top_card_key = mate_discard[0]


    for i in player_hand:
        if "Hearts" in i:
            count_hearts = count_hearts + 1
        if "Clubs" in i:
            count_clubs = count_clubs + 1
        if "Diamonds" in i:
            count_diamonds = count_diamonds + 1
        if "Spades" in i:
            count_spades = count_spades + 1

    ###Beginning "Hearts" iteration
    if opp1_discard[2] == "Hearts":
        if player_bid == 0:
            if count_hearts > 0:
                for i in sorted(player_hand, reverse=True):
                    if i[0] < top_card_key and i[2] == "Hearts":
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard
                for i in sorted(player_hand, reverse=True):
                    if i[2] == "Hearts":
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard

            if count_hearts == 0:
                for i in sorted(player_hand, reverse=True):
                    if count_clubs < count_diamonds:
                        if i[2] == "Hearts":
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard

                    if count_clubs > count_diamonds:
                        if i[2] == "Hearts":
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard
                    else:
                        if i[0] in range(1,39):
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard

        if mate_bid > 0:
            for i in sorted(player_hand, reverse=True):
                if (i[2] == "Clubs"
                    and top_card_key == mate_discard[0]
                    and i[0] < mate_discard[0]):
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard
                if (i[2] == "Hearts"
                    and top_card_key > mate_discard[0]
                    and i[0] < top_card_key):
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard
                if (i[2] == "Hearts"
                    and top_card_key > mate_discard[0]
                    and i[0] < top_card_key):
                    for v in player_hand:
                        if v[2] == "Hearts":
                            discard = v
                            player_hand.remove(discard)
                            return player_hand, discard

            if (mate_bid == 0
                and mate_discard[0] < top_card_key):
                for i in player_hand:
                    if i[2] == "Hearts":
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard

            if (mate_bid == 0
                and mate_discard[0] > top_card_key
                and mate_discard[2] == opp1_discard[2]):
                for i in sorted(player_hand, reverse=True):
                    if i[2] == "Hearts":
                        if i[0] > top_card_key:
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard
                for i in player_hand:
                    if i[2] == "Hearts":
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard

            for card in player_hand:
                if card[0] >= 40:
                    discard = card
                    player_hand.remove(discard)
                    return player_hand, discard

    ###Beginning "Clubs" iteration
    if opp1_discard[2] == "Clubs":
        if player_bid == 0:
            if count_clubs > 0:
                for i in sorted(player_hand, reverse=True):
                    if i[0] < top_card_key and i[0] in range(14,27):
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard
                for i in sorted(player_hand, reverse=True):
                    if i[2] == "Diamonds":
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard

            if count_clubs == 0:
                for i in sorted(player_hand, reverse=True):
                    if count_hearts < count_diamonds:
                        if i[2] == "Diamonds":
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard

                    if count_hearts > count_diamonds:
                        if i[2] == "Diamonds":
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard
                    else:
                        if i[0] in range(1,39):
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard

        if mate_bid > 0:
            for i in sorted(player_hand, reverse=True):
                if "Clubs" in i:
                    if (top_card_key == mate_discard[0]
                        and i[0] < mate_discard[0]):
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard
                    if (top_card_key > mate_discard[0]
                        and i[0] > top_card_key):
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard
                    if (top_card_key > mate_discard[0]
                        and i[0] < top_card_key):
                        for v in player_hand:
                            if "Clubs" in v:
                                discard = v
                                player_hand.remove(discard)
                                return player_hand, discard

        if (mate_bid == 0
            and mate_discard[0] < top_card_key):
            for i in player_hand:
                if "Clubs" in i:
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard

        if (mate_bid == 0
            and mate_discard[0] > top_card_key
            and mate_discard[2] == opp1_discard[2]):
            for i in sorted(player_hand, reverse=True):
                if "Clubs" in i:
                    if i[0] > top_card_key:
                        discard = i
                        player_hand.remove(discard)
                        return player_hand, discard
            for i in player_hand:
                if "Clubs" in i:
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard

        for card in player_hand:
            if card[0] >= 40:
                discard = card
                player_hand.remove(discard)
                return player_hand, discard

    ###Beginning "Diamonds" iterration
    if "Diamonds" in mate_discard:
        if player_bid == 0 and count_diamonds > 0:
            for i in sorted(player_hand, reverse=True):
                if i[0] < top_card_key and i[2] == "Diamonds":
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard
            for i in sorted(player_hand, reverse=True):
                if i[2] == "Diamonds":
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard

            if count_diamonds == 0:
                for i in sorted(player_hand, reverse=True):
                    if count_hearts < count_clubs:
                        if i[2] == "Hearts":
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard

                    if count_hearts > count_clubs:
                        if i[2] == "Clubs":
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard
                    else:
                        if i[0] in range(1,39):
                            discard = i
                            player_hand.remove(discard)
                            return player_hand, discard

        if mate_bid > 0:
            for i in sorted(player_hand, reverse=True):
                if (i[2] == "Diamonds"
                    and top_card_key == mate_discard[0]
                    and i[0] < mate_discard[0]):
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard
                if (i[2] == "Diamonds"
                    and top_card_key > mate_discard[0]
                    and i[0] > top_card_key):
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard
                if (i[2] == "Diamonds"
                    and top_card_key > mate_discard[0]
                    and i[0] < top_card_key):
                    for v in player_hand:
                        # This is a reverse loop to pull the lowest "Diamond"
                        if v[2] == "Diamonds":
                            discard = v
                            player_hand.remove(discard)
                            return player_hand, discard

        if (mate_bid == 0
            and mate_discard[0] < top_card_key
            and mate_discard[2] == opp1_discard[2]):
            for i in player_hand:
                if "Diamonds" in i:
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard

        if (mate_bid == 0
            and mate_discard[0] > top_card_key
            and mate_discard[2] == opp1_discard[2]):
            for i in player_hand:
                if "Diamonds" in i and i[0] > top_card_key:
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard

            for i in player_hand:
                if "Diamonds" in i:
                    discard = i
                    player_hand.remove(discard)
                    return player_hand, discard

        for card in player_hand:
            if card[0] >= 40:
                discard = card
                player_hand.remove(discard)
                return player_hand, discard

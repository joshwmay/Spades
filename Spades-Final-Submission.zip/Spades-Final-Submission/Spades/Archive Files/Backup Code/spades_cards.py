from spades_functions import *
import pandas as pd
import math
import random

class Cards:
    def __init__(self):
        """
        This class creates various attributes for a round of spades,
        and establishes the object frame work necessary to be used in logic and other facets of a
        game of spades
        """
        deck = initialize_spades(spades_deal(shuffled(spades_deck())))

        self.turn = deck[0]
        self.spades_break = 1

        p1_dict = dict()
        p1 = sorted(set(deck[1]))
        self.p1_c1 = p1[0]
        self.p1_c2 = p1[1]
        self.p1_c3 = p1[2]
        self.p1_c4 = p1[3]
        self.p1_c5 = p1[4]
        self.p1_c6 = p1[5]
        self.p1_c7 = p1[6]
        self.p1_c8 = p1[7]
        self.p1_c9 = p1[8]
        self.p1_c10 = p1[9]
        self.p1_c11 = p1[10]
        self.p1_c12 = p1[11]
        self.p1_c13 = p1[12]
        self.p1 = sorted({self.p1_c1, self.p1_c2, self.p1_c3, self.p1_c4,\
                             self.p1_c5, self.p1_c6, self.p1_c7, self.p1_c8,\
                             self.p1_c9, self.p1_c10, self.p1_c11, self.p1_c12,\
                             self.p1_c13})


        self.p1_bid = int(deck[2])


        self.p2 = sorted(set(deck[3]))
        self.p2_bid = int(deck[4])


        self.p3 = sorted(set(deck[5]))
        self.p3_bid = int(deck[6])


        self.p4 = sorted(set(deck[7]))
        self.p4_bid = int(deck[8])

        self.team1_bids = self.p1_bid, self.p3_bid
        self.team2_bids = self.p2_bid, self.p4_bid

        self.suits = {"Hearts", "Clubs", "Diamonds", "Spades"}

        self.score_frame = pd.DataFrame({"Bids":[0, 0, 0, 0,"nan"],"Wins":[0, 0, 0, 0, 0], "Bags":[0, 0, 0, 0, 0], "Score":[0,0,0,0,0]}, index = ["Player 1", "Player 2", "Player 3", "Player 4","Winner"])

    def order(self, winner):
        """ This method has been created to determine the order of discarding
            for any round other than the first one """
        if n == 1:
            return [1,2,3,4]
        if n == 2:
            return [2,3,4,1]
        if n == 3:
            return [3,4,1,2]
        if n == 4:
            return [4,1,2,3]

    def add_frame(self, n, df, p1_disc, p2_disc, p3_disc, p4_disc, winner):
        """ This method is used to update a data frame with a new column, while accounting for the winner"""
        frame = pd.DataFrame({"Hand " + str(n):[p1_disc, p2_disc, p3_disc, p4_disc,        winner ]}, index = ["Player 1", "Player 2", "Player 3", "Player 4","Winner"])
        winner = frame["Hand " + str(n)].loc["Winner"]
        df["Wins"]["Player " + str(winner)] += 1

        return_frame = pd.concat([df, frame], axis = 1)
        return return_frame

    def add_calculation(self, df):
        """ This method is to be used at the end of a round to calculate the scores for both teams"""
        for num in range(1,4):
            if num == 3:
                return df
            elif num == 1:
                mate = 3
            elif num == 2:
                mate = 4

            wins = df["Wins"]["Player " + str(num)]
            bids = df["Bids"]["Player " + str(num)]
            bags = wins - bids

            mate_wins = df["Wins"]["Player " + str(mate)]
            mate_bids = df["Bids"]["Player " + str(mate)]
            mate_bags = mate_wins - mate_bids

            team_wins = wins + mate_wins
            team_bids = bids + mate_bids
            team_bags = bags + mate_bags


            if team_wins < team_bids and bids != 0 and mate_bids != 0:
                df["Score"]["Player " + str(num)] -= 50


            elif team_wins >= team_bids and bids != 0 and mate_bids != 0:
                df["Score"]["Player " + str(num)] +=  team_bids * 10
                df["Bags"]["Player " + str(num)] += team_bags


            elif team_wins == team_bids and bids != 0 and mate_bids != 0:
                df["Score"]["Player " + str(num)] +=  team_bids * 10
                df["Bags"]["Player " + str(num)] += 0


            elif bids == 0 and team_wins >= team_bids:
                if wins > 0:
                    df["Score"]["Player " + str(num)] +=  (team_bids * 10) - 100
                    df["Bags"]["Player " + str(num)] += team_bags

                elif wins == 0:
                    df["Score"]["Player " + str(num)] +=  (team_bids * 10) + 100
                    df["Bags"]["Player " + str(num)] += team_bags

            elif mate_bids == 0 and team_wins >= team_bids:
                if mate_wins > 0:
                    df["Score"]["Player " + str(num)] +=  (team_bids * 10) - 100
                    df["Bags"]["Player " + str(num)] += team_bags

                elif mate_wins == 0:
                    df["Score"]["Player " + str(num)] +=  (team_bids * 10) + 100
                    df["Bags"]["Player " + str(num)] += team_bags

            elif bids == 0 and team_wins <= team_bids:
                if wins > 0:
                    df["Score"]["Player " + str(num)] -=  150
                    df["Bags"]["Player " + str(num)] += team_bags

                elif wins == 0:
                    df["Score"]["Player " + str(num)] +=  50
                    df["Bags"]["Player " + str(num)] += team_bags

            elif mate_bids == 0 and team_wins <= team_bids:
                if mate_wins > 0:
                    df["Score"]["Player " + str(num)] -=  150
                    df["Bags"]["Player " + str(num)] += team_bags

                elif mate_wins == 0:
                    df["Score"]["Player " + str(num)] -=  150
                    df["Bags"]["Player " + str(num)] += team_bags

    def hearts(self, p_hand):
        """ This method counts hearts, and will help in logic for discards"""
        count = counter(p_hand)
        return count[0]

    def clubs(self, p_hand):
        """ This method counts clubs, and will help in logic for discards"""
        count = counter(p_hand)
        return count[1]

    def diamonds(self, p_hand):
        """ This method counts diamonds, and will help in logic for discards"""
        count = counter(p_hand)
        return count[2]

    def spades(self, p_hand):
        """ This method counts spades, and will help in logic for discards"""
        count = counter(p_hand)
        return count[3]

    def max_suit(self, p_hand):
        hearts = self.hearts(p_hand)
        clubs = self.clubs(p_hand)
        diamonds = self.diamonds(p_hand)
        spades = self.spades(p_hand)
        """ This method determines the suit with the most cards in a given hand"""
        if(hearts >= clubs and hearts >= diamonds and hearts >= spades):
            return "Hearts"
        elif(clubs >= hearts and clubs >= diamonds and clubs >= spades):
            return "Clubs"
        elif(diamonds >= hearts and diamonds >= clubs and diamonds >= spades):
            return "Diamonds"
        elif(spades >= hearts and spades >= clubs and spades >= diamonds):
            return "Spades"

    def min_suit(self, p_hand):
        hearts = self.hearts(p_hand)
        clubs = self.clubs(p_hand)
        diamonds = self.diamonds(p_hand)
        spades = self.spades(p_hand)
        """ This method determines the suit with the least cards in a given hand"""
        if(hearts <= clubs and hearts <= diamonds and hearts <= spades):
            return "Hearts"
        elif(clubs <= hearts and clubs <= diamonds and clubs <= spades):
            return "Clubs"
        elif(diamonds <= hearts and diamonds <= clubs and diamonds <= spades):
            return "Diamonds"
        elif(spades <= hearts and spades <= clubs and spades <= diamonds):
            return "Spades"

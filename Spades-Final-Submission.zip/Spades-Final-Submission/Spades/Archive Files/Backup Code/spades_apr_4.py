from spades import *

def bid(player):
    """
    This function serves to create automated bids for computer players in the
    game of spades

    Args:
        deal(multiple lists of tuples) - The playing cards for each player in
                                         a game of spades
    Returns:
        bid: An integer bid number
    """
    bid = 0
    spades = 0
    hearts = 0
    diamonds = 0
    clubs = 0
    for card in player:
        if card[0] in range(1,14):
            hearts = hearts + 1
        if card[0] in range(14,27):
            clubs = clubs + 1
        if card[0] in range(27,40):
            diamonds = diamonds + 1
        if card[0] in range(40,53):
            spades = spades + 1
        if (card[1] == "Ace"
            or card[1] == "King"):
            bid = bid + 1
    if hearts < 2 and spades > 2:
        bid = bid + 2
    if diamonds < 2 and spades > 2:
        bid = bid + 2
    if clubs < 2 and spades > 2:
        bid = bid + 2
    if (hearts + diamonds + clubs) < 7 and spades > 5:
        bid = bid + 1
    return bid

def initialize_spades(deck):
    """
    This function initiates a deck of cards intended for a game of spades,
    gives bids for 4 players, and returns a hand for each player

    Args:
        deck(list of tuples) - A shuffled list of sorted cards

    Returns:
        first_bid(int) - A randomized player set to bid and discard first
        p1(list of tuples) - A hand of cards for a player in spades
        p1_bid(int) - An automated bid number
        p2(list of tuples) - A hand of cards for a player in spades
        p2_bid(int) - An automated bid number
        p3(list of tuples) - A hand of cards for a player in spades
        p3_bid(int) - An automated bid number
        p4(list of tuples) - A hand of cards for a player in spades
        p4_bid(int) - An automated bid number
    """
    x = 0
    for i in deck: #Same structure could be used for
        x = x + 1
        if x == 1:
            p1 = i
            if (1,2,"Hearts") in p1:
                first_bid = 1
        if x == 2:
            p2 = i
            if (1,2,"Hearts") in p2:
                first_bid = 2
        if x == 3:
            p3 = i
            if (1,2,"Hearts") in p3:
                first_bid = 3
        if x == 4:
            p4 = i
            if (1,2,"Hearts") in p4:
                first_bid = 4
    if first_bid == 1:
        p1_bid = bid(p1)
        p2_bid = bid(p2)
        if p1_bid == 0:
            p3_bid = bid(p3) + 1
        if p1_bid > 0:
            p3_bid = bid(p3)
        if p2_bid == 0:
            p4_bid = bid(p4) + 1
        if p2_bid > 0:
            p4_bid = bid(p4)
        if p1_bid + p2_bid + p3_bid + p4_bid < 13:
            p4_bid = p4_bid + 1
        if p1_bid + p2_bid + p3_bid + p4_bid >= 13:
            p4_bid = p4_bid - 1
    if first_bid == 2:
        p2_bid = bid(p2)
        p3_bid = bid(p3)
        if p2_bid == 0:
            p4_bid = bid(p4) + 1
        if p2_bid > 0:
            p4_bid = bid(p4)
        if p3_bid == 0:
            p1_bid = bid(p1) + 1
        if p3_bid > 0:
            p1_bid = bid(p1)
        if p1_bid + p2_bid + p3_bid + p4_bid < 13:
            p1_bid = p1_bid + 1
        if p1_bid + p2_bid + p3_bid + p4_bid >= 14:
            p1_bid = p1_bid - 1
    if first_bid == 3:
        p3_bid = bid(p3)
        p4_bid = bid(p4)
        if p3_bid == 0:
            p1_bid = bid(p1) + 1
        if p3_bid > 0:
            p1_bid = bid(p1)
        if p4_bid == 0:
            p2_bid = bid(p2) + 1
        if p4_bid > 0:
            p2_bid = bid(p2)
        if p1_bid + p2_bid + p3_bid + p4_bid < 13:
            p2_bid = p2_bid + 1
        if p1_bid + p2_bid + p3_bid + p4_bid >= 14:
            p2_bid = p2_bid - 1
    if first_bid == 4:
        p4_bid = bid(p4)
        p1_bid = bid(p1)
        if p4_bid == 0:
            p2_bid = bid(p2) + 1
        if p4_bid > 0:
            p2_bid = bid(p2)
        if p1_bid == 0:
            p3_bid = bid(p3) + 1
        if p1_bid > 0:
            p3_bid = bid(p3)
        if p1_bid + p2_bid + p3_bid + p4_bid < 13:
            p3_bid = p3_bid + 1
        if p1_bid + p2_bid + p3_bid + p4_bid >= 13:
            p3_bid = p3_bid - 1
    return first_bid , p1, p1_bid, p2, p2_bid, p3, p3_bid, p4, p4_bid

g = initialize_spades(spades_deal(shuffled(spades_deck())))


def play_round(deck_bids):
    """
    This function is in progress, but separates a shuffled deck and bids,
    then assigns bids and hands to given variables

    Args:
        deck_bids(list of tuples) - A returned list of hands and bids for
                                    players in Spades
    """
    turn = deck_bids[0]
    p1 = sorted(set(deck_bids[1]))
    p1_bid = deck_bids[2]
    p2 = sorted(set(deck_bids[3]))
    p2_bid = deck_bids[4]
    p3 = sorted(set(deck_bids[5]))
    p3_bid = deck_bids[6]
    p4 = sorted(set(deck_bids[7]))
    p4_bid = deck_bids[8]
    total = p1_bid + p2_bid + p3_bid + p4_bid
    print(total, "\n", p1_bid, p1,"\n",p2_bid,p2,"\n",p3_bid,p3,"\n",p4_bid,p4)

play_round(g)

import tkinter as tk
from PIL import ImageTk, Image


# suite = input("Enter a card suite: ")
# cardnum = input("Enter a card number: ")

window = tk.Tk()

import random
import math

def spades_deck():
    """
    This function creates a deck of cards to be used in a game of spades

    Returns:
        ready_to_shuffle(list) - An indexed list of card tuples grouped by suit,
                                 in ascending order by face value and suit,
                                 with Spades being the highest indexed suit
    """
    ready_for_shuffle = []
    for num in range(1,53):
        if num < 14 :
            suit = "Hearts"
            file_suit = "h"
            if num < 10:
                face = num + 1
                file_face = str(face)
        if 13 < num < 27:
            suit = "Clubs"
            file_suit = "c"
            if 13 < num < 23:
                face = (num + 1) - 13
                file_face = str(face)
        if 26 < num < 40:
            suit = "Diamonds"
            file_suit = "d"
            if 26 < num < 36:
                face = (num + 1) - (13 * 2)
                file_face = str(face)
        if 39 < num < 53:
            suit = "Spades"
            file_suit = "s"
            if 39 < num < 49:
                face = (num + 1) - (13 * 3)
                file_face = str(face)
        if (num == 10 or num == 23 or num == 36 or num == 49):
            face = "Jack"
            file_face = "j"
        if (num == 11 or num == 24 or num == 37 or num == 50):
            face = "Queen"
            file_face = "q"
        if (num == 12 or num == 25 or num == 38 or num == 51):
            face = "King"
            file_face = "k"
        if (num == 13 or num == 26 or num == 39 or num == 52):
            face = "Ace"
            file_face = "1"
        card_point = (num, face, suit, file_face + file_suit)
        ready_for_shuffle +=  [card_point]
    return ready_for_shuffle

def shuffled(deck):
    """
    This function shuffles a deck of cards

    Args:
        deck(list or tuples) - A list of card tuples to be shuffled

    Returns:
        deck(list of tuples) - A shuffled deck of cards
    """
    random.shuffle(deck)
    return deck

def spades_deal(deck):
    """
    This function deals out cards to 4 players playing spades from a shuffled
    deck

    Args:
        deck(list of tuples) - A deck of cards to be shuffled for spades

    Returns:
        p1(list of tuples) - A list of tuples for player 1, to be used as cards
        p2(list of tuples) - A list of tuples for player 2, to be used as cards
        p3(list of tuples) - A list of tuples for player 3, to be used as cards
        p4(list of tuples) - A list of tuples for player 4, to be used as cards
    """
    p1 = []
    p2 = []
    p3 = []
    p4 = []
    x = 0
    for i in deck:
        x = x + 1
        if x < 14:
            p1.append(i)
        if 13 < x < 27:
            p2.append(i)
        if 26 < x < 40:
            p3.append(i)
        if 39 < x < 53:
            p4.append(i)
    return sorted(p1), sorted(p2), sorted(p3), sorted(p4)

def discard():
    print("dealing this card!")

deck = spades_deck()
deck = shuffled(deck)
p1, p2, p3, p4 = spades_deal(deck)
hand = p1
p1


window.title("Join")
window.geometry("300x300")
window.configure(background='grey')


path1 = hand[0][3] + ".png"
img1 = ImageTk.PhotoImage(Image.open(path1))
panel1 = tk.Button(window, image = img1, command =lambda: discard()).grid(row=1, column=1)

path2 = hand[1][3] + ".png"
img2 = ImageTk.PhotoImage(Image.open(path2))
panel2 = tk.Button(window, image = img2).grid(row=1, column=2)

path3 = hand[2][3] + ".png"
img3 = ImageTk.PhotoImage(Image.open(path3))
panel3 = tk.Button(window, image = img3).grid(row=1, column=3)

path4 = hand[3][3] + ".png"
img4 = ImageTk.PhotoImage(Image.open(path4))
panel4 = tk.Button(window, image = img4).grid(row=1, column=4)

path5 = hand[4][3] + ".png"
img5 = ImageTk.PhotoImage(Image.open(path5))
panel5 = tk.Button(window, image = img5).grid(row=1, column=5)

path6 = hand[5][3] + ".png"
img6 = ImageTk.PhotoImage(Image.open(path6))
panel6 = tk.Button(window, image = img6).grid(row=1, column=6)

path7 = hand[6][3] + ".png"
img7 = ImageTk.PhotoImage(Image.open(path7))
panel7 = tk.Button(window, image = img7).grid(row=1, column=7)

path8 = hand[7][3] + ".png"
img8 = ImageTk.PhotoImage(Image.open(path8))
panel8 = tk.Button(window, image = img8).grid(row=1, column=8)

path9 = hand[8][3] + ".png"
img9 = ImageTk.PhotoImage(Image.open(path9))
panel9 = tk.Button(window, image = img9).grid(row=1, column=9)

path10 = hand[9][3] + ".png"
img10 = ImageTk.PhotoImage(Image.open(path10))
panel10 = tk.Button(window, image = img10).grid(row=1, column=10)

path11 = hand[10][3] + ".png"
img11 = ImageTk.PhotoImage(Image.open(path11))
panel11 = tk.Button(window, image = img11).grid(row=1, column=11)

path12 = hand[11][3] + ".png"
img12 = ImageTk.PhotoImage(Image.open(path12))
panel12 = tk.Button(window, image = img12).grid(row=1, column=12)

path13 = hand[12][3] + ".png"
img13 = ImageTk.PhotoImage(Image.open(path13))
panel13 = tk.Button(window, image = img13).grid(row=1, column=13)

window.mainloop()

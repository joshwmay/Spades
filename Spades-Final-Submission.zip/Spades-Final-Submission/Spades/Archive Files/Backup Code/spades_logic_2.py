from spades_apr_4 import *


def segment_hand(p_hand, p_bid):
    hearts = 0
    clubs = 0
    diamonds = 0
    spades = 0
    potentials = []
    avoids = []
    for enum, face, suit in p_hand:
        if suit == "Hearts":
            hearts += 1
            if (face == "Ace"
                or face == "King"
                or face == "Queen"
                or face == "Jack"
                and p_bid > 0):
                card = enum, face, suit
                potentials.append(card)
            if (face == "Ace"
                or face == "King"
                or face == "Queen"
                or face == "Jack"
                and p_bid == 0):
                card = enum, face, suit
                avoids.append(card)
            else:
                card = enum, face, suit
                avoids.append(card)

        if suit == "Clubs":
            clubs += 1
            if (face == "Ace"
                or face == "King"
                or face == "Queen"
                or face == "Jack"
                and p_bid > 0):
                card = enum, face, suit
                potentials.append(card)
            if (face == "Ace"
                or face == "King"
                or face == "Queen"
                or face == "Jack"
                and p_bid == 0):
                card = enum, face, suit
                avoids.append(card)
            else:
                card = enum, face, suit
                avoids.append(card)

        if suit == "Diamonds":
            diamonds += 1
            if (face == "Ace"
                or face == "King"
                or face == "Queen"
                or face == "Jack"
                and p_bid > 0):
                card = enum, face, suit
                potentials.append(card)
            if (face == "Ace"
                or face == "King"
                or face == "Queen"
                or face == "Jack"
                and p_bid == 0):
                card = enum, face, suit
                avoids.append(card)
            else:
                card = enum, face, suit
                avoids.append(card)

        if suit == "Spades":
            spades += 1
            if p_bid > 0:
                card = enum, face, suit
                potentials.append(card)
            else:
                card = enum, face, suit
                avoids.append(card)


    max_min = max_min_suit(hearts, clubs, diamonds, spades)
    max_suit = max_min[0]
    min_suit = max_min[1]
    return (sorted(set(potentials)), sorted(set(avoids)),max_suit, min_suit)

def max_min_suit(hearts, clubs, diamonds, spades):
    if (hearts < clubs and hearts < diamonds and hearts < spades):
        min_suit = "Hearts"
    if (clubs < hearts and clubs < diamonds and clubs < spades):
        min_suit = "Clubs"
    if (diamonds < hearts and diamonds < clubs and diamonds < spades):
        min_suit = "Diamonds"
    if (spades < hearts and spades < clubs and spades < diamonds):
        min_suit = "Spades"

    if (hearts > clubs and hearts > diamonds and hearts > spades):
        max_suit = "Hearts"
    if (clubs > hearts and clubs > diamonds and clubs > spades):
        max_suit = "Clubs"
    if (diamonds > hearts and diamonds > clubs and diamonds > spades):
        max_suit = "Diamonds"
    if (spades > hearts and spades > clubs and spades > diamonds):
        max_suit = "Spades"
    return max_suit, min_suit

def first_logic(p_hand, p_bid, mate_bid, spades_break):
    """
    This function works to return a discard for the first player in a frame

    Args:
        p_hand(set) - The set of cards in a players hand
        p_bid(int) - The bid of the player whose discard will be returned
        mate_bid(int) - The teammates bid of the player whose discard will
                        be returned
        spades_break(boolean) - True/False value that
                                serves as a rule for discards

    Returns:
        p_hand(set) - The player's hand with discard removed
        discard(tuple) - The player's discard
        spades_break(boolean) - True/False value
                                (True if no Spades previously played,
                                False if Spades previously played)

    Side Effects:
        p_hand is returned with one less card
    """
    hand_unwrap = segment_hand(p_hand, p_bid)
    potentials = hand_unwrap[0]
    avoids = hand_unwrap[1]
    max_suit = hand_unwrap[2]
    min_suit = hand_unwrap[3]

    if spades_break:
        if (p_bid > 0
            and mate_bid > 0):
            for enum, face, suit in sorted(potentials, reverse = True):
                if suit != "Spades":
                    if suit == max_suit:
                        discard = enum, face, suit
                        p_hand.remove(discard)
                        spades_break = True
                        return p_hand, discard, spades_break

            for enum, face, suit in avoids:
                if suit != "Spades" and suit == min_suit:
                    discard = enum, face, suit
                    p_hand.remove(discard)
                    spades_break = True
                    return p_hand, discard, spades_break

            for enum, face, suit in sorted(p_hand):
                discard = enum, face, suit
                if suit == "Spades":
                    spades_break = False
                p_hand.remove(discard)
                return p_hand, discard, spades_break

        if (p_bid > 0
            and mate_bid == 0):
            for enum, face, suit in potentials:
                if suit != "Spades":
                    discard = enum, face, suit
                    p_hand.remove(discard)
                    spades_break = True
                    return p_hand, discard, spades_break
            for enum, face, suit in sorted(avoids, reverse = True):
                if suit != "Spades" and suit == max_suit:
                    discard = enum, face, suit
                    p_hand.remove(discard)
                    spades_break = True
                    return p_hand, discard, spades_break
            for enum, face, suit in sorted(p_hand):
                discard = enum, face, suit
                if suit == "Spades":
                    spades_break = False
                p_hand.remove(discard)
                return p_hand, discard, spades_break

        if p_bid == 0:
            for enum, face, suit in sorted(p_hand):
                if suit != "Spades":
                    discard = enum, face, suit
                    p_hand.remove(discard)
                    spades_break = True
                    return p_hand, discard, spades_break

            for enum, face, suit in sorted(p_hand):
                if suit == "Spades":
                    discard = enum, face, suit
                    p_hand.remove(discard)
                    spades_break = False
                    return p_hand, discard, spades_break

    if not spades_break:
        if (p_bid > 0
            and mate_bid > 0):
            for enum, face, suit in sorted(potentials, reverse = True):
                if suit == max_suit:
                    discard = enum, face, suit
                    p_hand.remove(discard)
                    spades_break = False
                    return p_hand, discard, spades_break

            for enum, face, suit in avoids:
                if suit != "Spades" and suit == min_suit:
                    discard = enum, face, suit
                    p_hand.remove(discard)
                    spades_break = False
                    return p_hand, discard, spades_break

        if (p_bid > 0
            and mate_bid == 0):
            for enum, face, suit in potentials:
                discard = enum, face, suit
                p_hand.remove(discard)
                spades_break = False
                return p_hand, discard, spades_break
            for enum, face, suit in sorted(avoids, reverse = True):
                if suit == max_suit:
                    discard = enum, face, suit
                    p_hand.remove(discard)
                    spades_break = False
                    return p_hand, discard, spades_break
            for enum, face, suit in sorted(p_hand):
                discard = enum, face, suit
                spades_break = False
                p_hand.remove(discard)
                return p_hand, discard, spades_break

        if p_bid == 0:
            for enum, face, suit in sorted(p_hand):
                if suit == max_suit:
                    discard = enum, face, suit
                    p_hand.remove(discard)
                    spades_break = False
                    return p_hand, discard, spades_break


#def second_logic(set_suit, p2, p2_bid, p4_bid, p1_disc, spades_break):
t = initialize_spades(spades_deal(shuffled(spades_deck())))
g = first_logic(t[1],t[2],t[6], spades_break = True)
print(g[1])

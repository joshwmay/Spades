from spades_functions import *
from spades_cards import Cards
import pandas as pd
import numpy as np
import math
import random

class Discard(Cards):
    def __init__(self):
        Cards.__init__(self)
        self.p1_discs = []
        self.p2_discs = []
        self.p3_discs = []
        self.p4_discs = []

    def remove_card(self, player, card):
        for i in player:
            if i == card:
                return player.remove(card)

    def flog(self, p_hand, p_bid, mate_bid, spades_break):
        """ This method is to be used in determining an automated discard
        for a player taking the first turn

        Args:
            p_hand(list of tuples) - The hand of the player discarding
            p_bid(int) - The bid of the player discarding
            min_suit(str) - The suit with the least cards
            max_suit(str) - The suit with the most cards
            spades_break(int) - Either a 1 or 0, used for boolean purposes

        Returns:
            p_hand(list of tuples) - The cards in a player's hand with the discard removed
            discard(tuple) - An enum_erator, face value, and suit for the card discarded
            spades_break(int) - Either a 1 or 0, used for boolean purposes
            (set of string integers) - The left over enum_urators to be used in GUI environment
        """
        highs = ["Jack","Queen","King","Ace"]# These segments
        mids = [7,8,9,10]                    # are to be used with faces
        lows = [2,3,4,5,6]                   # in p_hand
        min_suit = self.min_suit(p_hand)
        max_suit = self.max_suit(p_hand)
        while spades_break == 1:
            if p_bid == 0:#####################################################
                for enum_, face, suit in p_hand:
                    if (suit != "Spades"
                        and face in lows
                        or face in mids):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if (suit == max_suit):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)

                        return p_hand, discard, 1

                    elif face in lows:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if face in mids or face in lows and suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if face != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

            elif p_bid != 0:###################################################
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if face in highs and suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if (suit != "Spades"
                        and face in lows
                        or face in mids
                        or suit == min_suit):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

        while spades_break == 0:
            if p_bid == 0:                                                #p_bid
                for enum_, face, suit in p_hand:
                    if (suit == min_suit and face in lows):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                    elif (suit == max_suit and face not in highs):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                        for enum_, face, suit in p_hand:
                            discard = (enum_, face, suit)
                            p_hand.remove(discard)
                            return p_hand, discard, 0

            if p_bid != 0:####################################  pbid  ##########
                for enum_, face, suit in p_hand:
                    if (suit == max_suit and face in highs):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                    elif suit == min_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0


    def slog(self, p_hand, p_bid, mate_bid, first_disc, spades_break):
        """ This method is to be used in determining an automated discard
        for a player taking the second turn

        Args:
            p_hand(list of tuples) - The hand of the player discarding
            p_bid(int) - The bid of the player discarding
            mate_bid(int) - The bid of the teammate for the player discarding
            first_disc(tuple) - The card discarded in the first turn
            spades_break(int) - Either a 1 or 0, used for boolean purposes

        Returns:
            p_hand(list of tuples) - The cards in a player's hand with the
                                     discard removed
            discard(tuple) - An enum_erator, face value, and suit for the card
                             discarded
            spades_break(int) - Either a 1 or 0, used for boolean purposes
        """
        highs = ["Jack","Queen","King","Ace"]
        mids = [7,8,9,10]
        lows = [2,3,4,5,6]
        set_suit = first_disc[2]

        while spades_break == 1:
            if p_bid != 0 and mate_bid:                                                #p_bid
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if (suit == set_suit and enum_ > first_disc[0]):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit == set_suit and enum_ < first_disc[0]:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                    elif suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

            if p_bid == 0:                                                #pbid
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ < first_disc[0]:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

        while spades_break == 0:
            if p_bid != 0:
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ > first_disc[0]:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                    elif suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0

            if p_bid == 0:
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ < first_disc[0]:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0


    def tlog(self, p_hand, p_bid, mate_bid, mate_disc, opp_disc, spades_break):
        """ This method is to be used in determining an automated discard
        for a player taking the third turn

        Args:
            p_hand(list of tuples) - The hand of the player discarding
            p_bid(int) - The bid of the player discarding
            mate_bid(int) - The bid of the teammate for the player discarding
            mate_disc(tuple) - The card discarded in the first turn
            opp_disc(tuble) - The card discarded in the second turn
            spades_break(int) - Either a 1 or 0, used for boolean purposes

        Returns:
            p_hand(list of tuples) - The cards in a player's hand with the discard removed
            discard(tuple) - An enum_erator, face value, and suit for the card discarded
            spades_break(int) - Either a 1 or 0, used for boolean purposes
            (set of string integers) - The left over enum_urators to be used in GUI environment
        """
        highs = ["Jack","Queen","King","Ace"]
        mids = [7,8,9,10]
        lows = [2,3,4,5,6]

        set_suit = mate_disc[2]
        mate_enum_ = mate_disc[0]

        opp_suit = opp_disc[2]
        opp_enum_ = opp_disc[0]

        while spades_break == 1:
            if (p_bid != 0
                and mate_enum_ < opp_enum_
                and set_suit != opp_suit):
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ > opp_enum_:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                    elif suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 1

            if p_bid != 0 and mate_enum_ > opp_enum_:
                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                    if suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

            if p_bid == 0:
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ < mate_enum_ or enum_ < opp_enum_:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                    if suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

        while spades_break == 0:
            if (p_bid != 0
                and mate_enum_ < opp_enum_
                and set_suit == opp_suit):
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ > opp_enum_:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0
            elif (p_bid != 0
                  and mate_enum_ < opp_enum_
                  and opp_suit != set_suit):
                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0

            elif p_bid != 0 and mate_enum_ > opp_enum_:
                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0

            if p_bid == 0:
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ < opp_enum_ or enum_ < mate_enum_:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0

            for enum_, face, suit in p_hand:
                discard = (enum_, face, suit)
                p_hand.remove(discard)
                return p_hand, discard, 0

    def four_log(self, p_hand, p_bid, mate_bid, mate_disc, opp_disc, opp2_disc,\
                 spades_break):
        """ This method is to be used in determining an automated discard
        for a player taking the third turn

        Args:
            p_hand(list of tuples) - The hand of the player discarding
            p_bid(int) - The bid of the player discarding
            mate_bid(int) - The bid of the teammate for the player discarding
            mate_disc(tuple) - The card discarded in the first turn
            opp_disc(tuble) - The card discarded in the second turn
            spades_break(int) - Either a 1 or 0, used for boolean purposes

        Returns:
            p_hand(list of tuples) - The cards in a player's hand with the discard removed
            discard(tuple) - An enum_erator, face value, and suit for the card discarded
            spades_break(int) - Either a 1 or 0, used for boolean purposes
            (set of string integers) - The left over enum_urators to be used in GUI environment
        """
        highs = ["Jack","Queen","King","Ace"]
        mids = [7,8,9,10]
        lows = [2,3,4,5,6]

        mate_suit = mate_disc[2]
        mate_enum_ = mate_disc[0]

        set_suit = opp_disc[2]
        opp_enum_ = opp_disc[0]
        opp2_suit = opp2_disc[2]
        opp2_enum_ = opp2_disc[0]

        while spades_break == 1:
            if (p_bid != 0 and mate_enum_ < opp_enum_ or mate_enum_ < opp2_enum_):
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ > opp_enum_ and enum_ > opp2_enum_ :
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == set_suit and enum_ < opp_enum_ and enum_ < opp2_enum_:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
            if p_bid != 0:
                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

            if (p_bid != 0
                and mate_enum_ > opp_enum_
                and mate_enum_ > opp_enum_
                or mate_suit == set_suit):
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ < mate_enum_:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                    if suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0


            if p_bid == 0:
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if (suit == set_suit
                        and (enum_ < opp_enum_
                        or enum_ < mate_enum_
                        or enum_ < opp2_enum_)):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                    if suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

        while spades_break == 0:
            if p_bid != 0 and mate_enum_ < opp_enum_ or mate_enum_ < opp2_enum_:
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ > opp_enum_:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0

            if p_bid != 0 and mate_enum_ > opp_enum_ and mate_enum_ > opp2_enum_:
                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
                for enum_, face, suit in p_hand:
                    if suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0

            if p_bid == 0:
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if (suit == set_suit
                        and enum_ < opp_enum_
                        or enum_ < mate_enum_
                        or enum_ < opp2_enum_):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    if suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0

            for enum_, face, suit in p_hand:
                discard = (enum_, face, suit)
                p_hand.remove(discard)
                return p_hand, discard, 0


    def winner(self, p1_disc, p2_disc, p3_disc, p4_disc, set_suit):
        """ This method determines the winner based on 4 discards
        Args:
            p1_disc(tuple) - Discard from first turn
            p2_disc(tuple) - Discard from second turn
            p3_disc(tuple) - Discard from third turn
            p4_disc(tuple) - Discard from fourth turn

        Returns:
            winner(int) - An integer 1-4 representing the player that won"""
        for a, b, c in sorted(set([p1_disc, p2_disc, p3_disc, p4_disc]), reverse = True):
            if c == set_suit or c == "Spades":
                if (a,b,c) == p1_disc:
                    winner = 1
                if(a,b,c) == p2_disc:
                    winner = 2
                if(a,b,c) == p3_disc:
                    winner = 3
                if(a,b,c) == p4_disc:
                    winner = 4
                return winner

    def next_disc(self, turn):
        if turn == 1:
            while len(self.p2_discs) == len(self.p1_discs):
                bund = flog(self.p1, self.p1_bid, self.p3_bid, self.spades_break)
                self.p1 = bund[0]
                self.disc1 = bund[1]
                self.spades_break = bund[2]
                self.p1_discs.append(self.disc1)
            while len(self.p3_discs) == len(self.p2_discs):
                bund = slog(self.p2, self.p2_bid, self.p4_bid, self.disc1, self.spades_break)
                self.p2 = bund[0]
                self.disc2 = bund[1]
                self.spades_break = bund[2]
                self.p2_discs.append(self.disc2)
            while len(self.p4_discs) == len(self.p3_discs):
                p_hand, discard, s_b
                bund = tlog(self.p3, self.p3_bid, self.p1_bid, self.disc1, \
                            self.disc2, self.spades_break)
                self.p3 = bund[0]
                self.disc3 = bund[1]
                self.spades_break = bund[2]
                self.p3_discs.append(self.disc3)
            while len(self.p4_discs) < len(self.p3_discs):
                bund = four_log(self.p4, self.p4_bid, self.p2_bid, self.p2disc,\
                                self.p1disc, self.p3disc, self.spades_break)
                self.p4 = bund[0]
                self.disc4 = bund[1]
                self.spades_break = bund[2]
                self.p4_discs.append(self.disc4)

        if turn == 2:
            while len(self.p3_discs) == len(self.p2_discs):
                bund = flog(self.p2, self.p2_bid, self.p4_bid, self.spades_break)
                self.p2 = bund[0]
                self.p2disc = bund[1]
                self.spades_break = bund[2]
                self.p2_discs.append(self.p2disc)
            while len(self.p4_discs) == len(self.p3_discs):
                bund = slog(self.p3, self.p3_bid, self.p1_bid, self.p2disc, \
                            self.spades_break)
                self.p3 = bund[0]
                self.p3disc = bund[1]
                self.spades_break = bund[2]
                self.p3_discs.append(self.p3disc)
            while len(self.p1_discs) == len(self.p4_discs):
                bund = tlog(self.p4, self.p4_bid, self.p2_bid, self.p2disc, \
                            self.p3disc, self.spades_break)
                self.p4 = bund[0]
                self.p4disc = bund[1]
                self.spades_break = bund[2]
                self.p4_discs.append(self.p4disc)
            while len(self.p1_discs) < len(self.p4_discs):
                bund = four_log(self.p1, self.p1_bid, self.p3_bid, self.p3disc,\
                                self.p4disc, self.p2disc, self.spades_break )
                self.p1 = bund[0]
                self.p1disc = bund[1]
                self.spades_break = bund[2]
                self.p1_discs.append(self.p1disc)

        if turn == 3:
            while len(self.p4_discs) == len(self.p3_discs):
                bund = flog(self.p3, self.p3_bid, self.p1_bid,\
                            self.spades_break)
                self.p3 = bund[0]
                self.p3disc = bund[1]
                self.spades_break = bund[2]
                self.p3_discs.append(self.p3disc)
            while len(self.p1_discs) == len(self.p4_discs):
                bund = slog(self.p4, self.p4_bid, self.p3disc,\
                            self.spades_break)
                self.p4 = bund[0]
                self.p4disc = bund[1]
                self.spades_break = bund[2]
                self.p4_discs.append(self.p4disc)
            while len(self.p2_discs) == len(self.p1_discs):
                bund = tlog(self.p1, self.p1_bid, self.p3_bid, self.p3disc,\
                            self.p4disc, self.spades_break)
                self.p1 = bund[0]
                self.p1disc = bund[1]
                self.spades_break = bund[2]
                self.p1_discs.append(self.p1disc)
            while len(self.p2_discs) < len(self.p1_discs):
                bund = four_log(self.p2, self.p2_bid, self.p4_bid, self.p4disc,\
                                self.p3disc, self.p1disc)
                self.p2 = bund[0]
                self.p2disc = bund[1]
                self.spades_break = bund[2]
                self.p2_discs.append(self.p2disc)

        if turn == 4:
            while len(self.p1_discs) == len(self.p4_discs):
                bund = flog(self.p4, self.p4_bid, self.p2_bid,\
                            self.spades_break)
                self.p4 = bund[0]
                self.p4disc = bund[1]
                self.spades_break = bund[2]
                self.p4_discs.append(self.p4disc)
            while len(self.p2_discs) == len(self.p4_discs):
                bund = slog(self.p1, self.p1_bid, self.p4disc,\
                            self.spades_break)
                self.p1 = bund[0]
                self.p1disc = bund[1]
                self.spades_break = bund[2]
                self.p1_discs.append(self.p1disc)
            while len(self.p3_discs) == len(self.p4_discs):
                bund = tlog(self.p2, self.p2_bid, self.p4_bid, self.p4disc,\
                            self.p1disc, self.spades_break)
                self.p2 = bund[0]
                self.p2disc = bund[1]
                self.spades_break = bund[2]
                self.p2_discs.append(self.p2disc)
            while len(self.p3_discs) < len(self.p2_discs):
                bund = four_log(self.p3, self.p3_bid, self.p1_bid, self.p1disc,\
                                self.p4disc, self.p2disc)
                self.p3 = bund[0]
                self.p3disc = bund[1]
                self.spades_break = bund[2]
                self.p3_discs.append(self.p3disc)
        return self.remove_card(self.p1, self.p1disc),\
               self.remove_card(self.p2, self.p2disc),\
               self.remove_card(self.p3, self.p3disc),\
               self.remove_card(self.p4, self.p4disc),\
               self.spades_break

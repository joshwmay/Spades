def play_round():
    """
    This function is in progress, but separates a shuffled deck and bids,
    then assigns bids and hands to given variables

    Args:
        deck_bids(list of tuples) - A returned list of hands and bids for
                                    players in Spades
    """
    for i in range(1,14):
        deck_bids = initialize_spades(spades_deal(shuffled(spades_deck())))
        turn = deck_bids[0]
        p1_bid = deck_bids[2]
        p2_bid = deck_bids[4]
        p3_bid = deck_bids[6]
        p4_bid = deck_bids[8]
        if i == 1:
            spades_break = True
            p1 = set(deck_bids[1])
            p2 = set(deck_bids[3])
            p3 = set(deck_bids[5])
            p4 = set(deck_bids[7])
        round_frame = pd.DataFrame({"Bids":[p1_bid, p2_bid, p3_bid, p4_bid,\
        "nan"]}, index = ["Player 1", "Player 2", "Player 3", "Player 4","Winner"])
        hand_logic(i, turn, p1, p1_bid, p2, p2_bid, p3, p3_bid, p4, p4_bid, spades_break)

def hand_logic(frame, turn, p1_hand, p1_bid, p2_hand, p2_bid, p3_hand, p3_bid, p4_hand, p4_bid, spades_break):
    if turn == 1:
        p1_hand_disc = first_logic(p1, p1_bid, p3_bid, spades_break)
        p1 = p1_hand_disc[0]
        p1_disc = p1_hand_disc[1]
        set_suit = p1_disc[2]
        spades_break = p1_hand_disc[2]

        p2_hand_disc = second_logic(set_suit, p2, p2_bid, p4_bid, p1_disc, spades_break)
        p2 = p2_hand_disc[0]
        p2_disc = p2_hand_disc[1]

        p3_hand_disc = third_logic(set_suit, p3, p3_bid, p1_bid, p1_disc, p2_disc, spades_break)
        p3 = p3_hand_disc[0]
        p3_disc = p3_hand_disc[1]
        spades_break = p1_hand_disc[2]

        p4_hand_disc = fourth_logic(set_suit, p4, p4_bid, p2_bid, p1_disc, p3_disc, p3_disc, spades_break)
        p4_hand = p4_hand_disc[0]
        p4_disc = p4_hand_disc[1]
        spades_break = p4_hand_disc[2]



    if turn == 2:
        p2_hand_disc = first_logic(set_suit, p2, p2_bid, p4_bid, spades_break)
        p2 = p2_hand_disc[0]
        set_suit = p2_disc[2]
        p2_disc = p2_hand_disc[1]

        p3_hand_disc = second_logic(set_suit, p3, p3_bid, p1_bid, p2_disc,spades_break)
        p3 = p3_hand_disc[0]
        p3_disc = p3_hand_disc[1]
        spades_break = p1_hand_disc[2]

        p4_hand_disc = third_logic(set_suit, p4, p4_bid, p2_bid, p2_disc, p3_disc, spades_break)
        p4 = p4_hand_disc[0]
        p4_disc = p4_hand_disc[1]
        spades_break = p1_hand_disc[2]

        p1_hand_disc = fourth_logic(set_suit, p1, p1_bid, p3_bid, p3_disc, p2_disc, p4_disc, spades_break)
        p1_hand = p1_hand_disc[0]
        p1_disc = p1_hand_disc[1]
        spades_break = p1_hand_disc[2]

    if turn == 3:
        p3_hand_disc = first_logic(p3,p3_bid,p1_bid, spades_break)
        p3 = p3_hand_disc[0]
        p3_disc = p3_hand_disc[1]
        set_suit = p3_disc[2]
        spades_break = p3_hand_disc[2]

        p4_hand_disc = second_logic(set_suit, p4, p4_bid, p2_bid, p3_disc,spades_break)
        p4 = p4_hand_disc[0]
        p4_disc = p4_hand_disc[1]
        spades_break = p4_hand_disc[2]

        p1_hand_disc = third_logic(set_suit, p1, p1_bid, p3_bid, p3_disc, p4_disc, spades_break)
        p1 = p1_hand_disc[0]
        p1_disc = p1_hand_disc[1]
        spades_break = p1_hand_disc[2]

        p2_hand_disc = fourth_logic(set_suit, p2, p2_bid, p4_bid, p4_disc, p3_disc, p1_disc, spades_break)
        p2_hand = p2_hand_disc[0]
        p2_disc = p2_hand_disc[1]
        spades_break = p2_hand_disc[2]


    if turn == 4:
        p4_hand_disc = first_logic(p4,p4_bid,p2_bid, spades_break)
        p4 = p4_hand_disc[0]
        p4_disc = p4_hand_disc[1]
        set_suit = p4_disc[2]
        spades_break = p4_hand_disc[2]

        p1_hand_disc = second_logic(set_suit, p1, p1_bid, p3_bid, p4_disc,spades_break)
        p1 = p1_hand_disc[0]
        p1_disc = p1_hand_disc[1]
        spades_break = p1_hand_disc[2]

        p2_hand_disc = third_logic(set_suit, p2, p2_bid, p4_bid, p4_disc, p1_disc, spades_break)
        p2 = p2_hand_disc[0]
        p2_disc = p2_hand_disc[1]
        spades_break = p2_hand_disc[2]

        p3_hand_disc = fourth_logic(set_suit, p3, p3_bid, p1_bid, p1_disc, p4_disc, p2_disc, spades_break)
        p3_hand = p3_hand_disc[0]
        p3_disc = p3_hand_disc[1]
        spades_break = p3_hand_disc[2]

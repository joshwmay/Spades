from spades_functions import *
from spades_cards import Cards
from spades_discard import Discard
from spades_rules import Rules
import pandas as pd
import numpy as np
import math
import random
class SpadesRun(Cards):
    def __init__(self):
        Cards.__init__(self)
    def game_play(self, round):
        if round == 13:
            self.score_frame = self.rules.add_rnd_calc(self.score_frame)
            return self.score_frame
        elif round == 1:
            disc_shell = self.rules.next_disc(self.turn[0])
            self.p1disc = disc_shell[1]
            self.p1 = disc_shell[0]
            self.p2disc = disc_shell[3]
            self.p2 = disc_shell[2]
            self.p3disc = disc_shell[5]
            self.p3 = disc_shell[4]
            self.p4disc = disc_shell[7]
            self.p4 = disc_shell[6]
            self.spades_break = disc_shell[8]
            self.set_suit = disc_shell[9]
            self.winner = self.rules.winner_(self.p1disc, self.p2disc, self.p3disc,\
                                 self.p4disc, self.set_suit)
            self.score_frame = self.rules.add_frame(n, self.score_frame, self.p1disc,\
                                         self.p2disc, self.p3disc, self.p4disc,\
                                                                   self.winner)

        elif round in [2,3,4,5,6,7,8,9,10]:
            disc_shell = self.rules.next_disc(self.winner)
            self.p1disc = disc_shell[1]
            self.p1 = disc_shell[0]
            self.p2disc = disc_shell[3]
            self.p2 = disc_shell[2]
            self.p3disc = disc_shell[5]
            self.p3 = disc_shell[4]
            self.p4disc = disc_shell[7]
            self.p4 = disc_shell[6]
            self.spades_break = disc_shell[8]
            self.set_suit = disc_shell[9]
            self.winner = self.rules.winner_(self.p1disc, self.p2disc, self.p3disc, self.p4disc, self.set_suit)
            self.score_frame = self.rules.add_frame(round, self.score_frame, self.p1disc, self.p2disc, \
                                          self.p3disc, self.p4disc, self.winner)

game_test = SpadesRun()
game_test.game_play(1)
print(game_test.winner)

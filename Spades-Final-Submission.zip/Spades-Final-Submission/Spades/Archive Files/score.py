class Score():
    def __init__(self, team, bags):
        self.score = 0
        self.bags = bags
        self.team = team

    def __str__(self):
        return str(self.score)

    def get_score(self):
        team_score = self.score
        if self.team.successed_nil():
            team_score += 100
        elif self.team.failed_nil():
            team_score -= 100

        if self.team.made_bid():
            team_score += (self.team.bid * 10)
        else:
            team_score -= (self.team.bid * 10)

        if self.bags.has_gone_over():
            team_score -= 100

        self.score = team_score
        return self.score
    def update_score(self, board):
        if self.team.number == 1:
            board.team1_score = self.score
        else:
            board.team2_score = self.score

    def has_winning_score(self, game_score):
        return self.score >= game_score

from spades_cards import Cards
from spades_discard import Discard
from spades_functions import *
from spades_rules import Rules

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QComboBox, QPushButton, QTableWidgetItem
import time

class Ui_MainWindow(object):
    """ This class creates a GUI environment for the card game 'Spades'

        PCA - Pay Close Attention to patterns in PyQt5
            eg.
               ... = QtWidgets.QtWidget(...)
               ....setObjectName("...")
               ....setGeometry(QtCore.QRect(longAnch, latAnch, Diagonal, Width))
               ....setText("..")
               ....setPixmap(QtGui.QPixmap(".....PNG")
               ....raise_()

        Attributes:
            round_score (PyQt5 Table Widget): details the results of every round
            master_score (PyQt5 Table Widget): details the total score
            p1_disc_spot (PyQt5 Object): The spot for discards for player 1.
                Above holds true for p2, p3, and p4
            c1 [1-13] (Tuple): The cards in p1's hand

        Methods:
            display_card(n): Displays a card in p1's hand in the nth spot, given
                the card is in self.c[n]
            clear_discard(): Clears the disc_spot for every player
            bid_input(): Creates objects for a player to input a bid
            p1_disc(card): displays a given card in p1_disc_spot
                The above holds true for p2, p3, and p4.
            update_table_round(Cards, round): Updates the table to display round
                data
            update_score(Rules): Updates the score of the game
            update_table_bid(Cards): Updates the bids of the table
            takingturn(): Waits until the user finishes taking their turn

    """

    def setupUi(self, MainWindow):               # Create window
        MainWindow.setObjectName("SpadesWindow") # Name window
        MainWindow.resize(1122, 944)             # Size window
        MainWindow.setAutoFillBackground(False)  # ...
        MainWindow.setStyleSheet("")             # ...

        self.centralwidget = QtWidgets.QWidget(MainWindow) # ID main widget
        self.centralwidget.setObjectName("centralwidget") # Name main widget

        self.background = QtWidgets.QLabel(self.centralwidget)
        self.background.setGeometry(QtCore.QRect(-40, -60, 1261, 971))
        self.background.setText("")
        self.background.setPixmap(QtGui.QPixmap("background.png"))
        self.background.setObjectName("background")
        self.background.raise_()

        self.round_score = QtWidgets.QTableWidget(self.centralwidget)
        self.round_score.setGeometry(QtCore.QRect(170, 690, 891, 161))
        self.round_score.setMaximumSize(QtCore.QSize(931, 16777215))

        font = QtGui.QFont()
        font.setPointSize(7)

        self.round_score.setFont(font)
        self.round_score.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.round_score.setAutoFillBackground(False)
        self.round_score.setStyleSheet("")
        self.round_score.setVerticalScrollBarPolicy(QtCore.\
                                                    Qt.ScrollBarAlwaysOff)

        self.round_score.setHorizontalScrollBarPolicy(QtCore.\
                                                      Qt.ScrollBarAlwaysOff)

        self.round_score.setAutoScroll(False)
        self.round_score.setAutoScrollMargin(14)
        self.round_score.setAlternatingRowColors(True)
        self.round_score.setSelectionMode(QtWidgets.QAbstractItemView.\
                                                    ExtendedSelection)
        self.round_score.setSelectionBehavior(QtWidgets.\
                                              QAbstractItemView.SelectRows)
        self.round_score.setGridStyle(QtCore.Qt.SolidLine)
        self.round_score.setWordWrap(False)
        self.round_score.setCornerButtonEnabled(False)
        self.round_score.setRowCount(5)
        self.round_score.setColumnCount(15)
        self.round_score.setObjectName("round_score")
        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        item.setFont(font)

        for n in range(0,5):
            self.round_score.setVerticalHeaderItem(n, item)
            item = QtWidgets.QTableWidgetItem()
            font = QtGui.QFont()
            font.setPointSize(8)
            font.setBold(True)
            font.setWeight(75)
            item.setFont(font)

        for n in range(0,15):
            self.round_score.setHorizontalHeaderItem(n, item)
            item = QtWidgets.QTableWidgetItem()
            font = QtGui.QFont()
            font.setPointSize(8)
            font.setBold(True)
            font.setWeight(75)
            item.setFont(font)


        item = QtWidgets.QTableWidgetItem()
        brush = QtGui.QBrush(QtGui.QColor(0, 0, 0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        item.setBackground(brush)
        brush = QtGui.QBrush(QtGui.QColor(0, 0, 0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        item.setForeground(brush)

        self.round_score.setItem(4, 0, item)
        item = QtWidgets.QTableWidgetItem()
        brush = QtGui.QBrush(QtGui.QColor(0, 0, 0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        item.setBackground(brush)
        brush = QtGui.QBrush(QtGui.QColor(0, 0, 0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        item.setForeground(brush)

        self.round_score.setItem(4, 1, item)
        self.round_score.horizontalHeader().setVisible(True)
        self.round_score.horizontalHeader().setCascadingSectionResizes(False)
        self.round_score.horizontalHeader().setDefaultSectionSize(55)
        self.round_score.horizontalHeader().setMinimumSectionSize(60)
        self.round_score.verticalHeader().setDefaultSectionSize(25)


        item = QtWidgets.QTableWidgetItem(0)
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(False)
        font.setWeight(75)
        item.setFont(font)
        self.round_score.setItem(0,0, item)

        item = QtWidgets.QTableWidgetItem(0)
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(False)
        font.setWeight(75)
        item.setFont(font)
        self.round_score.setItem(1,0, item)

        item = QtWidgets.QTableWidgetItem(0)
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(False)
        font.setWeight(75)
        item.setFont(font)
        self.round_score.setItem(2,0, item)

        item = QtWidgets.QTableWidgetItem(0)
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(False)
        font.setWeight(75)
        item.setFont(font)
        self.round_score.setItem(3,0, item)

        self.drops = []

        self.discard_box = QtWidgets.QGroupBox(self.centralwidget)
        self.discard_box.setGeometry(QtCore.QRect(299, 109, 491, 411))
        self.discard_box.setTitle("")
        self.discard_box.setObjectName("discard_box")
        self.p3_disc_spot = QtWidgets.QLabel(self.discard_box)
        self.p3_disc_spot.setGeometry(QtCore.QRect(210, 40, 81, 111))
        self.p3_disc_spot.setStyleSheet("border-color: rgb(25, 25, 25);\n"
        "background-color: rgb(118, 118, 118);")
        self.p3_disc_spot.setObjectName("p3_disc_spot")
        self.gridLayout = QtWidgets.QGridLayout(self.p3_disc_spot)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.gridLayout.setObjectName("gridLayout")
        self.p1_disc_spot = QtWidgets.QLabel(self.discard_box)
        self.p1_disc_spot.setGeometry(QtCore.QRect(210, 270, 81, 111))
        self.p1_disc_spot.setStyleSheet("border-color: rgb(25, 25, 25);\n"
        "background-color: rgb(118, 118, 118);")
        self.p1_disc_spot.setObjectName("p1_disc_spot")
        self.gridLayout_3 = QtWidgets.QGridLayout(self.p1_disc_spot)
        self.gridLayout_3.setContentsMargins(0, 0, 0, 0)
        self.gridLayout_3.setObjectName("gridLayout_3")
        self.p2_disc_spot = QtWidgets.QLabel(self.discard_box)
        self.p2_disc_spot.setGeometry(QtCore.QRect(30, 140, 81, 111))
        self.p2_disc_spot.setStyleSheet("border-color: rgb(25, 25, 25);\n"
        "background-color: rgb(118, 118, 118);")
        self.p2_disc_spot.setObjectName("p2_disc_spot")
        self.gridLayout_4 = QtWidgets.QGridLayout(self.p2_disc_spot)
        self.gridLayout_4.setContentsMargins(0, 0, 0, 0)
        self.gridLayout_4.setObjectName("gridLayout_4")
        self.p4_disc_spot = QtWidgets.QLabel(self.discard_box)
        self.p4_disc_spot.setGeometry(QtCore.QRect(380, 140, 81, 111))
        self.p4_disc_spot.setStyleSheet("border-color: rgb(25, 25, 25);\n"
        "background-color: rgb(118, 118, 118);")
        self.p4_disc_spot.setObjectName("p4_disc_spot")
        self.gridLayout_5 = QtWidgets.QGridLayout(self.p4_disc_spot)
        self.gridLayout_5.setContentsMargins(0, 0, 0, 0)
        self.gridLayout_5.setObjectName("gridLayout_5")

        self.rnd_trigger = QtWidgets.QPushButton(self.centralwidget)
        self.rnd_trigger.setGeometry(QtCore.QRect(10, 500, 80, 25))
        self.rnd_trigger.setText("Play Round")
        self.rnd_trigger.setObjectName("rnd_trigger")
        self.rnd_trigger.raise_()

        self.scr_trigger = QtWidgets.QPushButton(self.centralwidget)
        self.scr_trigger.setGeometry(QtCore.QRect(10, 700, 150, 25))
        self.scr_trigger.setText("Score Round")
        self.scr_trigger.setObjectName("scr_trigger")
        self.scr_trigger.raise_()

        self.p1cards = QtWidgets.QGroupBox(self.centralwidget)
        self.p1cards.setGeometry(QtCore.QRect(10, 550, 1051, 141))
        self.p1cards.setObjectName("self.p1cards")

        spacer_pivot = 10
        spacer = 80
        x = 0
        for i in range(1,14):
            spacer = 30
            self.p2_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p2_cards.setGeometry(QtCore.QRect(90, 20, 171, 531))
            self.p2_cards.setTitle("")
            self.p2_cards.setObjectName("p2_cards")
            x += 1
            self.label = QtWidgets.QLabel(self.p2_cards)
            self.label.setGeometry(QtCore.QRect(60, x * spacer, 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()

        x = 0
        for i in range(1,14):
            self.p3_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p3_cards.setGeometry(QtCore.QRect(300, 0, 491, 111))
            self.p3_cards.setTitle("")
            self.p3_cards.setObjectName("p3_cards")
            x += 1
            self.label = QtWidgets.QLabel(self.p3_cards)
            self.label.setGeometry(QtCore.QRect(30 * x, 10, 71, 101))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back2.png"))

            self.label.raise_()

        x = 0
        for i in range(1,14):
            self.p4_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p4_cards.setGeometry(QtCore.QRect(820, 30, 171, 531))
            self.p4_cards.setTitle("")
            self.p4_cards.setObjectName("p4_cards")
            x += 1
            meas = 20 + (x * 30)
            self.label = QtWidgets.QLabel(self.p4_cards)
            self.label.setGeometry(QtCore.QRect(10, meas, 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()


        self.master_score = QtWidgets.QTableWidget(self.centralwidget)
        self.master_score.setGeometry(QtCore.QRect(10, 740, 151, 111))
        font = QtGui.QFont()
        font.setPointSize(7)
        self.master_score.setFont(font)
        self.master_score.setAutoFillBackground(False)
        self.master_score.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.master_score.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.master_score.setAutoScroll(False)
        self.master_score.setTabKeyNavigation(False)
        self.master_score.setProperty("showDropIndicator", False)
        self.master_score.setAlternatingRowColors(True)
        self.master_score.setGridStyle(QtCore.Qt.SolidLine)
        self.master_score.setCornerButtonEnabled(False)
        self.master_score.setRowCount(2)
        self.master_score.setColumnCount(2)
        self.master_score.setObjectName("master_score")

        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        item.setFont(font)
        self.master_score.setVerticalHeaderItem(0, item)

        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        item.setFont(font)

        self.master_score.setVerticalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        item.setFont(font)
        self.master_score.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        item.setFont(font)
        self.master_score.setHorizontalHeaderItem(1, item)
        self.master_score.horizontalHeader().setVisible(True)
        self.master_score.horizontalHeader().setCascadingSectionResizes(False)
        self.master_score.horizontalHeader().setDefaultSectionSize(45)
        self.master_score.horizontalHeader().setMinimumSectionSize(40)
        self.master_score.verticalHeader().setVisible(True)
        self.master_score.verticalHeader().setDefaultSectionSize(40)

        self.p1cards.raise_()
        self.discard_box.raise_()
        self.p2_cards.raise_()
        self.p3_cards.raise_()
        self.master_score.raise_()
        self.round_score.raise_()
        self.p4_cards.raise_()
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1122, 26))
        self.menubar.setObjectName("menubar")
        self.menuSpades = QtWidgets.QMenu(self.menubar)
        self.menuSpades.setObjectName("menuSpades")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.menubar.addAction(self.menuSpades.menuAction())

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.p1wins = 0
        self.p2wins = 0
        self.p3wins = 0
        self.p4wins = 0

        self.round_score.setItem(0, 1, QTableWidgetItem(str(self.p1wins)))
        self.round_score.setItem(1, 1, QTableWidgetItem(str(self.p2wins)))
        self.round_score.setItem(2, 1, QTableWidgetItem(str(self.p3wins)))
        self.round_score.setItem(3, 1, QTableWidgetItem(str(self.p4wins)))

    def auto_drop_card(self, hand, cardex):
        for card in self.drops:
            hand.remove(cardex)
            break

    def reset_discs(self, cards):
        cards.p1disc = None
        cards.p2disc = None
        cards.p3disc = None
        cards.p4disc = None
        cards.set_suit = None
        cards.round += 1
        return cards.p1disc, cards.p2disc, cards.p3disc, cards.p4disc,\
               cards.set_suit, cards.round

    def on_click(self, index, cards, cardex, disc_class):
        if cards.started == 0:
            pass
        index.hide()
        cards.p1disc = cardex
        cards.p1_discs.append(cardex)
        if cards.spades_break == 1 and cardex[2] =="Spades":
            cards.spades_break = 0
        if cards.spades_break == 1 and cardex[2] !="Spades":
            cards.spades_break = 1
        if cards.spades_break == 0:
            cards.spades_break = 0
        cards.started = 0
        if cards.turn[0] == 1:
            cards.set_suit = cardex[2]
            return disc_class.after_user_disc(cards, cards.p1disc),\
    self.p1_disc_spot.setPixmap(QtGui.QPixmap(str(cards.p1disc[0])+".png")),\
    self.p2_disc_spot.setPixmap(QtGui.QPixmap(str(cards.p2disc[0])+".png")),\
    self.p3_disc_spot.setPixmap(QtGui.QPixmap(str(cards.p3disc[0])+".png")),\
    self.p4_disc_spot.setPixmap(QtGui.QPixmap(str(cards.p4disc[0])+".png")),\
    cards.started
        if cards.turn[1] == 1:
            return disc_class.after_user_disc(cards, cards.p1disc),\
    self.p1_disc_spot.setPixmap(QtGui.QPixmap(str(cards.p1disc[0])+".png")),\
    self.p2_disc_spot.setPixmap(QtGui.QPixmap(str(cards.p2disc[0])+".png")),\
    self.p3_disc_spot.setPixmap(QtGui.QPixmap(str(cards.p3disc[0])+".png")),\
    cards.started

        if cards.turn[2] == 1:
            return disc_class.after_user_disc(cards, cards.p1disc),\
    self.p1_disc_spot.setPixmap(QtGui.QPixmap(str(cards.p1disc[0])+".png")),\
    self.p2_disc_spot.setPixmap(QtGui.QPixmap(str(cards.p2disc[0])+".png")),\
    cards.started

        if cards.turn[3] == 1:
            return cards.p1, cards.p1disc, cards.p1_discs,\
    self.p1_disc_spot.setPixmap(QtGui.QPixmap(str(cards.p1disc[0])+".png")),\
    cards.started, cards.spades_break

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.p1cards.setTitle(_translate("MainWindow", "Your Cards"))
        item = self.master_score.verticalHeaderItem(0)
        item.setText(_translate("MainWindow", "Team1"))
        item = self.master_score.verticalHeaderItem(1)
        item.setText(_translate("MainWindow", "Team2"))
        item = self.master_score.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "Score"))
        item = self.master_score.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "Bags"))
        self.round_score.setSortingEnabled(False)
        item = self.round_score.verticalHeaderItem(0)
        item.setText(_translate("MainWindow", "Player 1"))
        item = self.round_score.verticalHeaderItem(1)
        item.setText(_translate("MainWindow", "Player 2"))
        item = self.round_score.verticalHeaderItem(2)
        item.setText(_translate("MainWindow", "Player 3"))
        item = self.round_score.verticalHeaderItem(3)
        item.setText(_translate("MainWindow", "Player 4"))
        item = self.round_score.verticalHeaderItem(4)
        item.setText(_translate("MainWindow", "Winner"))
        item = self.round_score.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "Bid"))
        item = self.round_score.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "Wins"))
        item = self.round_score.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "Rnd 1"))
        item = self.round_score.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "Rnd 2"))
        item = self.round_score.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "Rnd 3"))
        item = self.round_score.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", "Rnd 4"))
        item = self.round_score.horizontalHeaderItem(6)
        item.setText(_translate("MainWindow", "Rnd 5"))
        item = self.round_score.horizontalHeaderItem(7)
        item.setText(_translate("MainWindow", "Rnd 6"))
        item = self.round_score.horizontalHeaderItem(8)
        item.setText(_translate("MainWindow", "Rnd 7"))
        item = self.round_score.horizontalHeaderItem(9)
        item.setText(_translate("MainWindow", "Rnd 8"))
        item = self.round_score.horizontalHeaderItem(10)
        item.setText(_translate("MainWindow", "Rnd 9"))
        item = self.round_score.horizontalHeaderItem(11)
        item.setText(_translate("MainWindow", "Rnd 10"))
        item = self.round_score.horizontalHeaderItem(12)
        item.setText(_translate("MainWindow", "Rnd 11"))
        item = self.round_score.horizontalHeaderItem(13)
        item.setText(_translate("MainWindow", "Rnd 12"))
        item = self.round_score.horizontalHeaderItem(14)
        item.setText(_translate("MainWindow", "Rnd 13"))
        __sortingEnabled = self.round_score.isSortingEnabled()
        self.round_score.setSortingEnabled(False)
        self.round_score.setSortingEnabled(__sortingEnabled)
        self.menuSpades.setTitle(_translate("MainWindow", "Spades"))

    def display_card(self, n, cards, card):

        """
        Displays a given card in the location of a specific place for player 1.

        Args:
            n (int): The number card to be displayed by p1.
        """

        spacer_pivot = 10
        spacer = 80
        if n == 1:
             card1_icon = QtGui.QIcon()
             card1_icon.addPixmap(QtGui.QPixmap(str(card[0])+".PNG"),
                                  QtGui.QIcon.Normal, QtGui.QIcon.Off)
             self.card1 = QtWidgets.QPushButton(self.p1cards)
             self.card1.setGeometry(QtCore.QRect(10, 20, 71, 101))

             self.card1.setIcon(card1_icon)
             self.card1.setIconSize(QtCore.QSize(256, 256))
             self.card1.setObjectName(str(card))
             self.card1.raise_()
             self.card1.show()
        if n == 2:

            card2_icon = QtGui.QIcon()
            card2_icon.addPixmap(QtGui.QPixmap(str(card[0])+".PNG"),
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.card2 = QtWidgets.QPushButton(self.p1cards)
            self.card2.setGeometry(QtCore.QRect(1 * spacer + 10,\
                                                      20, 71, 101))

            self.card2.setIcon(card2_icon)
            self.card2.setIconSize(QtCore.QSize(256, 256))
            self.card2.setObjectName(str(card))
            self.card2.raise_()
            self.card2.show()
        if n == 3:
            card3_icon = QtGui.QIcon()
            card3_icon.addPixmap(QtGui.QPixmap(str(card[0])+".PNG"),
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.card3 = QtWidgets.QPushButton(self.p1cards)
            self.card3.setGeometry(QtCore.QRect(2 * spacer + 10,\
                                                      20, 71, 101))

            self.card3.setIcon(card3_icon)
            self.card3.setIconSize(QtCore.QSize(256, 256))
            self.card3.setObjectName(str(card))
            self.card3.raise_()
            self.card3.show()
        if n == 4:
            card4_icon = QtGui.QIcon()
            card4_icon.addPixmap(QtGui.QPixmap(str(card[0])+".PNG"),
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.card4 = QtWidgets.QPushButton(self.p1cards)
            self.card4.setGeometry(QtCore.QRect(3 * spacer + 10,\
                                                      20, 71, 101))

            self.card4.setIcon(card4_icon)
            self.card4.setIconSize(QtCore.QSize(256, 256))
            self.card4.setObjectName(str(card))
            self.card4.raise_()
            self.card4.show()
        if n == 5:
            card5_icon = QtGui.QIcon()
            card5_icon.addPixmap(QtGui.QPixmap(str(card[0])+".PNG"),
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.card5 = QtWidgets.QPushButton(self.p1cards)
            self.card5.setGeometry(QtCore.QRect(4 * spacer + 10,\
                                                      20, 71, 101))

            self.card5.setIcon(card5_icon)
            self.card5.setIconSize(QtCore.QSize(256, 256))
            self.card5.setObjectName(str(card))
            self.card5.raise_()
            self.card5.show()
        if n == 6:
            card6_icon = QtGui.QIcon()
            card6_icon.addPixmap(QtGui.QPixmap(str(card[0])+".PNG"),
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.card6 = QtWidgets.QPushButton(self.p1cards)
            self.card6.setGeometry(QtCore.QRect(5 * spacer + 10,\
                                                      20, 71, 101))

            self.card6.setIcon(card6_icon)
            self.card6.setIconSize(QtCore.QSize(256, 256))
            self.card6.setObjectName(str(card))
            self.card6.raise_()
            self.card6.show()
        if n == 7:
            card7_icon = QtGui.QIcon()
            card7_icon.addPixmap(QtGui.QPixmap(str(card[0])+".PNG"),
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.card7 = QtWidgets.QPushButton(self.p1cards)
            self.card7.setGeometry(QtCore.QRect(6 * spacer + 10,\
                                                      20, 71, 101))

            self.card7.setIcon(card7_icon)
            self.card7.setIconSize(QtCore.QSize(256, 256))
            self.card7.setObjectName(str(card))
            self.card7.raise_()
            self.card7.show()
        if n == 8:
            card8_icon = QtGui.QIcon()
            card8_icon.addPixmap(QtGui.QPixmap(str(card[0])+".PNG"),
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.card8 = QtWidgets.QPushButton(self.p1cards)
            self.card8.setGeometry(QtCore.QRect(7 * spacer + 10,\
                                                      20, 71, 101))

            self.card8.setIcon(card8_icon)
            self.card8.setIconSize(QtCore.QSize(256, 256))
            self.card8.setObjectName(str(card))
            self.card8.raise_()
            self.card8.show()
        if n == 9:
            card9_icon = QtGui.QIcon()
            card9_icon.addPixmap(QtGui.QPixmap(str(card[0])+".PNG"),
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.card9 = QtWidgets.QPushButton(self.p1cards)
            self.card9.setGeometry(QtCore.QRect(8 * spacer + 10,\
                                                      20, 71, 101))

            self.card9.setIcon(card9_icon)
            self.card9.setIconSize(QtCore.QSize(256, 256))
            self.card9.setObjectName(str(card))
            self.card9.raise_()
            self.card9.show()
        if n == 10:
            card10_icon = QtGui.QIcon()
            card10_icon.addPixmap(QtGui.QPixmap(str(card[0])+".PNG"),
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.card10 = QtWidgets.QPushButton(self.p1cards)
            self.card10.setGeometry(QtCore.QRect(9 * spacer + 10,\
                                                      20, 71, 101))

            self.card10.setIcon(card10_icon)
            self.card10.setIconSize(QtCore.QSize(256, 256))
            self.card10.setObjectName(str(card))
            self.card10.raise_()
            self.card10.show()
        if n == 11:
            card11_icon = QtGui.QIcon()
            card11_icon.addPixmap(QtGui.QPixmap(str(card[0])+".PNG"),
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.card11 = QtWidgets.QPushButton(self.p1cards)
            self.card11.setGeometry(QtCore.QRect(10 * spacer + 10,\
                                                      20, 71, 101))

            self.card11.setIcon(card11_icon)
            self.card11.setIconSize(QtCore.QSize(256, 256))
            self.card11.setObjectName(str(card))
            self.card11.raise_()
            self.card11.show()
        if n == 12:
            card12_icon = QtGui.QIcon()
            card12_icon.addPixmap(QtGui.QPixmap(str(card[0])+".PNG"),
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.card12 = QtWidgets.QPushButton(self.p1cards)
            self.card12.setGeometry(QtCore.QRect(11 * spacer + 10,\
                                                      20, 71, 101))

            self.card12.setIcon(card12_icon)
            self.card12.setIconSize(QtCore.QSize(256, 256))
            self.card12.setObjectName(str(card))
            self.card12.raise_()
            self.card12.show()
        if n == 13:
            card13_icon = QtGui.QIcon()
            card13_icon.addPixmap(QtGui.QPixmap(str(card[0])+".PNG"),
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.card13 = QtWidgets.QPushButton(self.p1cards)
            self.card13.setGeometry(QtCore.QRect(12 * spacer + 10,\
                                                      20, 71, 101))

            self.card13.setIcon(card13_icon)
            self.card13.setIconSize(QtCore.QSize(256, 256))
            self.card13.setObjectName(str(card))
            self.card13.raise_()
            self.card13.show()

    def display_card_all(self, cards):
        self.display_card(1, cards, cards.c1)
        self.display_card(2, cards, cards.c2)
        self.display_card(3, cards, cards.c3)
        self.display_card(4, cards, cards.c4)
        self.display_card(5, cards, cards.c5)
        self.display_card(6, cards, cards.c6)
        self.display_card(7, cards, cards.c7)
        self.display_card(8, cards, cards.c8)
        self.display_card(9, cards, cards.c9)
        self.display_card(10, cards, cards.c10)
        self.display_card(11, cards, cards.c11)
        self.display_card(12, cards, cards.c12)
        self.display_card(13, cards, cards.c13)




    def clear_discard(self):
        """
        Resets the image of all 4 discard piles, to be used at the end of
         a round.
        """
        self.p1_disc_spot.setPixmap(QtGui.QPixmap("back2.png"))
        self.p1_disc_spot.raise_()
        self.p2_disc_spot.setPixmap(QtGui.QPixmap("back2.png"))
        self.p2_disc_spot.raise_()
        self.p3_disc_spot.setPixmap(QtGui.QPixmap("back2.png"))
        self.p3_disc_spot.raise_()
        self.p4_disc_spot.setPixmap(QtGui.QPixmap("back2.png"))
        self.p4_disc_spot.raise_()

    def disc_click(self, cards, disc_class):
        cards.started = 1
        while cards.started == 1:
            if cards.turn[0] == 1:
                return cards.started
            if cards.turn[0] == 2:

                return disc_class.comp_discards(cards),\
     self.p2_disc_spot.setPixmap(QtGui.QPixmap(str(cards.p2disc[0])+".png")),\
     self.p3_disc_spot.setPixmap(QtGui.QPixmap(str(cards.p3disc[0])+".png")),\
     self.p4_disc_spot.setPixmap(QtGui.QPixmap(str(cards.p4disc[0])+".png")),\
     cards.started

            if cards.turn[0] == 3:
                return disc_class.comp_discards(cards),\
                       print("Trying..."),\
     self.p3_disc_spot.setPixmap(QtGui.QPixmap(str(cards.p3disc[0])+".png")),\
     self.p4_disc_spot.setPixmap(QtGui.QPixmap(str(cards.p4disc[0])+".png")),\
     cards.started

            if cards.turn[0] == 4:
                return disc_class.comp_discards(cards),\
    self.p4_disc_spot.setPixmap(QtGui.QPixmap(str(cards.p4disc[0])+".png")),\
    cards.started

    def p2disp(self, n):
        spacer = 30
        if n >= 1:
            self.p2_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p2_cards.setGeometry(QtCore.QRect(90, 20, 171, 531))
            self.p2_cards.setTitle("")
            self.p2_cards.setObjectName("p2_cards")
            self.label = QtWidgets.QLabel(self.p2_cards)
            self.label.setGeometry(QtCore.QRect(60, 1 * spacer, 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 2:
            self.p2_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p2_cards.setGeometry(QtCore.QRect(90, 20, 171, 531))
            self.p2_cards.setTitle("")
            self.p2_cards.setObjectName("p2_cards")
            self.label = QtWidgets.QLabel(self.p2_cards)
            self.label.setGeometry(QtCore.QRect(60, 2 * spacer, 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 3:
            self.p2_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p2_cards.setGeometry(QtCore.QRect(90, 20, 171, 531))
            self.p2_cards.setTitle("")
            self.p2_cards.setObjectName("p2_cards")
            self.label = QtWidgets.QLabel(self.p2_cards)
            self.label.setGeometry(QtCore.QRect(60, 3 * spacer, 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 4:
            self.p2_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p2_cards.setGeometry(QtCore.QRect(90, 20, 171, 531))
            self.p2_cards.setTitle("")
            self.p2_cards.setObjectName("p2_cards")
            self.label = QtWidgets.QLabel(self.p2_cards)
            self.label.setGeometry(QtCore.QRect(60, 4 * spacer, 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 5:
            self.p2_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p2_cards.setGeometry(QtCore.QRect(90, 20, 171, 531))
            self.p2_cards.setTitle("")
            self.p2_cards.setObjectName("p2_cards")
            self.label = QtWidgets.QLabel(self.p2_cards)
            self.label.setGeometry(QtCore.QRect(60, 5 * spacer, 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 6:
            self.p2_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p2_cards.setGeometry(QtCore.QRect(90, 20, 171, 531))
            self.p2_cards.setTitle("")
            self.p2_cards.setObjectName("p2_cards")
            self.label = QtWidgets.QLabel(self.p2_cards)
            self.label.setGeometry(QtCore.QRect(60, 6 * spacer, 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 7:
            self.p2_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p2_cards.setGeometry(QtCore.QRect(90, 20, 171, 531))
            self.p2_cards.setTitle("")
            self.p2_cards.setObjectName("p2_cards")
            self.label = QtWidgets.QLabel(self.p2_cards)
            self.label.setGeometry(QtCore.QRect(60, 7 * spacer, 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 8:
            self.p2_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p2_cards.setGeometry(QtCore.QRect(90, 20, 171, 531))
            self.p2_cards.setTitle("")
            self.p2_cards.setObjectName("p2_cards")
            self.label = QtWidgets.QLabel(self.p2_cards)
            self.label.setGeometry(QtCore.QRect(60, 8 * spacer, 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 9:
            self.p2_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p2_cards.setGeometry(QtCore.QRect(90, 20, 171, 531))
            self.p2_cards.setTitle("")
            self.p2_cards.setObjectName("p2_cards")
            self.label = QtWidgets.QLabel(self.p2_cards)
            self.label.setGeometry(QtCore.QRect(60, 9 * spacer, 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 10:
            self.p2_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p2_cards.setGeometry(QtCore.QRect(90, 20, 171, 531))
            self.p2_cards.setTitle("")
            self.p2_cards.setObjectName("p2_cards")
            self.label = QtWidgets.QLabel(self.p2_cards)
            self.label.setGeometry(QtCore.QRect(60, 10 * spacer, 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 11:
            self.p2_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p2_cards.setGeometry(QtCore.QRect(90, 20, 171, 531))
            self.p2_cards.setTitle("")
            self.p2_cards.setObjectName("p2_cards")
            self.label = QtWidgets.QLabel(self.p2_cards)
            self.label.setGeometry(QtCore.QRect(60, 11 * spacer, 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 12:
            self.p2_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p2_cards.setGeometry(QtCore.QRect(90, 20, 171, 531))
            self.p2_cards.setTitle("")
            self.p2_cards.setObjectName("p2_cards")
            self.label = QtWidgets.QLabel(self.p2_cards)
            self.label.setGeometry(QtCore.QRect(60, 12 * spacer, 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n == 13:
            self.p2_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p2_cards.setGeometry(QtCore.QRect(90, 20, 171, 531))
            self.p2_cards.setTitle("")
            self.p2_cards.setObjectName("p2_cards")
            self.label = QtWidgets.QLabel(self.p2_cards)
            self.label.setGeometry(QtCore.QRect(60, 13 * spacer, 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()

    def p3disp(self, n):
        if n >= 1:
            self.p3_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p3_cards.setGeometry(QtCore.QRect(300, 0, 491, 111))
            self.p3_cards.setTitle("")
            self.p3_cards.setObjectName("p3_cards")
            self.label = QtWidgets.QLabel(self.p3_cards)
            self.label.setGeometry(QtCore.QRect(30, 10, 71, 101))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back2.png"))
        if n >= 2:
            self.p3_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p3_cards.setGeometry(QtCore.QRect(300, 0, 491, 111))
            self.p3_cards.setTitle("")
            self.p3_cards.setObjectName("p3_cards")
            self.label = QtWidgets.QLabel(self.p3_cards)
            self.label.setGeometry(QtCore.QRect(30 * 2, 10, 71, 101))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back2.png"))
        if n >= 3:
            self.p3_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p3_cards.setGeometry(QtCore.QRect(300, 0, 491, 111))
            self.p3_cards.setTitle("")
            self.p3_cards.setObjectName("p3_cards")
            self.label = QtWidgets.QLabel(self.p3_cards)
            self.label.setGeometry(QtCore.QRect(30 * 3, 10, 71, 101))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back2.png"))
        if n >= 4:
            self.p3_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p3_cards.setGeometry(QtCore.QRect(300, 0, 491, 111))
            self.p3_cards.setTitle("")
            self.p3_cards.setObjectName("p3_cards")
            self.label = QtWidgets.QLabel(self.p3_cards)
            self.label.setGeometry(QtCore.QRect(30 * 4, 10, 71, 101))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back2.png"))
        if n >= 5:
            self.p3_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p3_cards.setGeometry(QtCore.QRect(300, 0, 491, 111))
            self.p3_cards.setTitle("")
            self.p3_cards.setObjectName("p3_cards")
            self.label = QtWidgets.QLabel(self.p3_cards)
            self.label.setGeometry(QtCore.QRect(30 * 5, 10, 71, 101))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back2.png"))
        if n >= 6:
            self.p3_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p3_cards.setGeometry(QtCore.QRect(300, 0, 491, 111))
            self.p3_cards.setTitle("")
            self.p3_cards.setObjectName("p3_cards")
            self.label = QtWidgets.QLabel(self.p3_cards)
            self.label.setGeometry(QtCore.QRect(30 * 6, 10, 71, 101))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back2.png"))
        if n >= 7:
            self.p3_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p3_cards.setGeometry(QtCore.QRect(300, 0, 491, 111))
            self.p3_cards.setTitle("")
            self.p3_cards.setObjectName("p3_cards")
            self.label = QtWidgets.QLabel(self.p3_cards)
            self.label.setGeometry(QtCore.QRect(30 * 7, 10, 71, 101))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back2.png"))
        if n >= 8:
            self.p3_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p3_cards.setGeometry(QtCore.QRect(300, 0, 491, 111))
            self.p3_cards.setTitle("")
            self.p3_cards.setObjectName("p3_cards")
            self.label = QtWidgets.QLabel(self.p3_cards)
            self.label.setGeometry(QtCore.QRect(30 * 8, 10, 71, 101))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back2.png"))
        if n >= 9:
            self.p3_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p3_cards.setGeometry(QtCore.QRect(300, 0, 491, 111))
            self.p3_cards.setTitle("")
            self.p3_cards.setObjectName("p3_cards")
            self.label = QtWidgets.QLabel(self.p3_cards)
            self.label.setGeometry(QtCore.QRect(30 * 9, 10, 71, 101))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back2.png"))
        if n >= 10:
            self.p3_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p3_cards.setGeometry(QtCore.QRect(300, 0, 491, 111))
            self.p3_cards.setTitle("")
            self.p3_cards.setObjectName("p3_cards")
            self.label = QtWidgets.QLabel(self.p3_cards)
            self.label.setGeometry(QtCore.QRect(30 * 10, 10, 71, 101))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back2.png"))
        if n >= 11:
            self.p3_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p3_cards.setGeometry(QtCore.QRect(300, 0, 491, 111))
            self.p3_cards.setTitle("")
            self.p3_cards.setObjectName("p3_cards")
            self.label = QtWidgets.QLabel(self.p3_cards)
            self.label.setGeometry(QtCore.QRect(30 * 11, 10, 71, 101))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back2.png"))
        if n >= 12:
            self.p3_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p3_cards.setGeometry(QtCore.QRect(300, 0, 491, 111))
            self.p3_cards.setTitle("")
            self.p3_cards.setObjectName("p3_cards")
            self.label = QtWidgets.QLabel(self.p3_cards)
            self.label.setGeometry(QtCore.QRect(30 * 12, 10, 71, 101))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back2.png"))
        if n == 13:
            self.p3_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p3_cards.setGeometry(QtCore.QRect(300, 0, 491, 111))
            self.p3_cards.setTitle("")
            self.p3_cards.setObjectName("p3_cards")
            self.label = QtWidgets.QLabel(self.p3_cards)
            self.label.setGeometry(QtCore.QRect(30 * 13, 10, 71, 101))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back2.png"))

    def p4disp(self, n):
        if n >= 1:
            self.p4_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p4_cards.setGeometry(QtCore.QRect(820, 30, 171, 531))
            self.p4_cards.setTitle("")
            self.p4_cards.setObjectName("p4_cards")
            self.label = QtWidgets.QLabel(self.p4_cards)
            self.label.setGeometry(QtCore.QRect(10, 20 + (1 * 30), 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 2:
            self.p4_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p4_cards.setGeometry(QtCore.QRect(820, 30, 171, 531))
            self.p4_cards.setTitle("")
            self.p4_cards.setObjectName("p4_cards")
            self.label = QtWidgets.QLabel(self.p4_cards)
            self.label.setGeometry(QtCore.QRect(10, 20 + (2 * 30), 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 3:
            self.p4_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p4_cards.setGeometry(QtCore.QRect(820, 30, 171, 531))
            self.p4_cards.setTitle("")
            self.p4_cards.setObjectName("p4_cards")
            self.label = QtWidgets.QLabel(self.p4_cards)
            self.label.setGeometry(QtCore.QRect(10, 20 + (3 * 30), 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 4:
            self.p4_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p4_cards.setGeometry(QtCore.QRect(820, 30, 171, 531))
            self.p4_cards.setTitle("")
            self.p4_cards.setObjectName("p4_cards")
            self.label = QtWidgets.QLabel(self.p4_cards)
            self.label.setGeometry(QtCore.QRect(10, 20 + (4 * 30), 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 5:
            self.p4_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p4_cards.setGeometry(QtCore.QRect(820, 30, 171, 531))
            self.p4_cards.setTitle("")
            self.p4_cards.setObjectName("p4_cards")
            self.label = QtWidgets.QLabel(self.p4_cards)
            self.label.setGeometry(QtCore.QRect(10, 20 + (5 * 30), 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 6:
            self.p4_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p4_cards.setGeometry(QtCore.QRect(820, 30, 171, 531))
            self.p4_cards.setTitle("")
            self.p4_cards.setObjectName("p4_cards")
            self.label = QtWidgets.QLabel(self.p4_cards)
            self.label.setGeometry(QtCore.QRect(10, 20 + (6 * 30), 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 7:
            self.p4_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p4_cards.setGeometry(QtCore.QRect(820, 30, 171, 531))
            self.p4_cards.setTitle("")
            self.p4_cards.setObjectName("p4_cards")
            self.label = QtWidgets.QLabel(self.p4_cards)
            self.label.setGeometry(QtCore.QRect(10, 20 + (7 * 30), 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 8:
            self.p4_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p4_cards.setGeometry(QtCore.QRect(820, 30, 171, 531))
            self.p4_cards.setTitle("")
            self.p4_cards.setObjectName("p4_cards")
            self.label = QtWidgets.QLabel(self.p4_cards)
            self.label.setGeometry(QtCore.QRect(10, 20 + (8 * 30), 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 8:
            self.p4_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p4_cards.setGeometry(QtCore.QRect(820, 30, 171, 531))
            self.p4_cards.setTitle("")
            self.p4_cards.setObjectName("p4_cards")
            self.label = QtWidgets.QLabel(self.p4_cards)
            self.label.setGeometry(QtCore.QRect(10, 20 + (8 * 30), 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 9:
            self.p4_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p4_cards.setGeometry(QtCore.QRect(820, 30, 171, 531))
            self.p4_cards.setTitle("")
            self.p4_cards.setObjectName("p4_cards")
            self.label = QtWidgets.QLabel(self.p4_cards)
            self.label.setGeometry(QtCore.QRect(10, 20 + (9 * 30), 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 10:
            self.p4_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p4_cards.setGeometry(QtCore.QRect(820, 30, 171, 531))
            self.p4_cards.setTitle("")
            self.p4_cards.setObjectName("p4_cards")
            self.label = QtWidgets.QLabel(self.p4_cards)
            self.label.setGeometry(QtCore.QRect(10, 20 + (10 * 30), 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 11:
            self.p4_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p4_cards.setGeometry(QtCore.QRect(820, 30, 171, 531))
            self.p4_cards.setTitle("")
            self.p4_cards.setObjectName("p4_cards")
            self.label = QtWidgets.QLabel(self.p4_cards)
            self.label.setGeometry(QtCore.QRect(10, 20 + (11 * 30), 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n >= 12:
            self.p4_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p4_cards.setGeometry(QtCore.QRect(820, 30, 171, 531))
            self.p4_cards.setTitle("")
            self.p4_cards.setObjectName("p4_cards")
            self.label = QtWidgets.QLabel(self.p4_cards)
            self.label.setGeometry(QtCore.QRect(10, 20 + (12 * 30), 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
        if n == 13:
            self.p4_cards = QtWidgets.QGroupBox(self.centralwidget)
            self.p4_cards.setGeometry(QtCore.QRect(820, 30, 171, 531))
            self.p4_cards.setTitle("")
            self.p4_cards.setObjectName("p4_cards")
            self.label = QtWidgets.QLabel(self.p4_cards)
            self.label.setGeometry(QtCore.QRect(10, 20 + (13 * 30), 101, 71))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap("back.png"))
            self.label.raise_()
    def bid_input(self):
        """
        Creates a widget for the user to input their desired bid.

        Returns:
            (int): The bid of the user, player 1.
        """
        print("starting bid method")
        self.bidBox = QComboBox(self.centralwidget)
        self.bidBox.setGeometry(QtCore.QRect(0, 300, 80, 25))
        self.bidBox.setObjectName(("comboBox"))
        self.bidBox.addItem('0')
        self.bidBox.addItem('1')
        self.bidBox.addItem('2')
        self.bidBox.addItem('3')
        self.bidBox.addItem('4')
        self.bidBox.addItem('5')
        self.bidBox.addItem('6')
        self.bidBox.addItem('7')
        self.bidBox.addItem('8')
        self.bidBox.addItem('9')
        self.bidBox.addItem('10')
        self.bidBox.addItem('11')
        self.bidBox.addItem('12')
        self.bidBox.addItem('13')
        self.bidButton = QPushButton('Bid', self.centralwidget)
        self.bidButton.setGeometry(QtCore.QRect(0, 275, 80, 25))
        self.bidButton.setToolTip('Select your bid.')
        self.bidButton.clicked.connect(self.clickBid)
        self.bidBox.show()
        self.bidButton.show()
        self.bidbool = 0
        print("entering loop")
        print(self.bidbool)
        while (self.bidbool == 0):
            QtCore.QCoreApplication.processEvents()
        self.bidBox.hide()
        self.bidButton.hide()
        return int(self.bidBox.currentText())


    def update_table_round(self, cards_class): # In Progress
        """
        Updates the round table at the end of the round.

        Args:
            data (Cards Class): The Cards Class contains the necessary data to
                update the scoring table with.
            winner (int): The number of the player that won
            r (int): Round Number
        """
        if cards.winner == 1:
            self.p1wins = self.p1wins + 1
            return\
            self.round_score.setItem(0, 1, QTableWidgetItem(str(self.p1wins)))
        elif cards.winner == 2:
            self.p2wins = self.p2wins + 1
            return\
            self.round_score.setItem(1, 1, QTableWidgetItem(str(self.p2wins)))
        elif cards.winner == 3:
            self.p3wins = self.p3wins + 1
            return\
            self.round_score.setItem(2, 1, QTableWidgetItem(str(self.p3wins)))
        elif cards.winner == 4:
            self.p4wins = self.p4wins + 1
            return\
            self.round_score.setItem(3, 1, QTableWidgetItem(str(self.p4wins)))







    def update_table_bid(self, cards_class):
        """
        Updates the round table for bids.

        Args:
            data (Cards Class): The Cards Class contains the necessary data to
                update the bids with.
        """

        self.round_score.setItem(0, 0, QTableWidgetItem(str(cards_class.p1_bid)))
        self.round_score.setItem(1, 0, QTableWidgetItem(str(cards_class.p2_bid)))
        self.round_score.setItem(2, 0, QTableWidgetItem(str(cards_class.p3_bid)))
        self.round_score.setItem(3, 0, QTableWidgetItem(str(cards_class.p4_bid)))


    def update_score(self, rules_class): # In Progress
        """
        Updates the scoring table.

        Args:
            data (Rules Class): The Rules Class contains the necessary data to
                update the scoring table with.
        """
        raise NotImplementedError
        t1s = ...
        t2s = ...
        t1b = ...
        t2b = ...
        self.master_score.setItem(0,0, QTableWidgetItem(str(t1s)))
        self.master_score.setItem(0,1, QTableWidgetItem(str(t1b)))
        self.master_score.setItem(1,0, QTableWidgetItem(str(t2s)))
        self.master_score.setItem(1,1, QTableWidgetItem(str(t2b)))


    def clickBid(self):
        """
        Changes bidbool to 1, exiting the loop to confirm the user's bid.

        Side Affects:
            Sets bidbool = 1.
        """
        self.bidbool = 1

    def clickcard(self):
        """
        Changes cardbool to 1, exiting the loop to confirm the user's card.

        Side Affects:
            Sets cardbool = 1.
        """
        print("clicked")
        self.cardbool = 1
    def ui_winner(self, cards, rules):
        winner = rules.winner_(cards, cards.p1disc, cards.p2disc, cards.p3disc,\
                               cards.p4disc, cards.set_suit)
        cards.winner = winner[0]
        cards.turn = winner[1]

        n = cards.round + 1

        self.clear_discard()

        return cards.winner, cards.turn,\
        self.round_score.setItem(0, n, QTableWidgetItem(str(cards.p1disc[1:]))),\
        self.round_score.setItem(1, n, QTableWidgetItem(str(cards.p2disc[1:]))),\
        self.round_score.setItem(2, n, QTableWidgetItem(str(cards.p3disc[1:]))),\
        self.round_score.setItem(3, n, QTableWidgetItem(str(cards.p4disc[1:]))),\
        self.round_score.setItem(4, n, QTableWidgetItem(str(cards.winner))),\
        self.update_table_round(cards), self.reset_discs(cards)


    def takingturn(self):
        """
        Waits until the player finishes taking their turn to progress.
        """

        self.cardbool = 0
        while (self.cardbool == 0):
            QtCore.QCoreApplication.processEvents()

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    cards = Cards()
    td = Discard()
    tr = Rules()
    ui.setupUi(MainWindow)
    MainWindow.show()
    ui.display_card_all(cards)
    cards.p1_bid = ui.bid_input()
    ui.update_table_bid(cards)
    ui.scr_trigger.clicked.connect(lambda: ui.ui_winner(cards = cards,\
                                                        rules = tr))
    ui.rnd_trigger.clicked.connect(lambda: ui.disc_click(cards = cards,\
                                                        disc_class = td))
    ui.card1.clicked.connect(lambda: ui.on_click(index = ui.card1,\
                             cards = cards, cardex = cards.c1, disc_class = td))
    ui.card2.clicked.connect(lambda: ui.on_click(index = ui.card2,\
                             cards = cards, cardex = cards.c2, disc_class = td))
    ui.card3.clicked.connect(lambda: ui.on_click(index = ui.card3,\
                             cards = cards, cardex = cards.c3, disc_class = td))
    ui.card4.clicked.connect(lambda: ui.on_click(index = ui.card4,\
                             cards = cards, cardex = cards.c4, disc_class = td))
    ui.card5.clicked.connect(lambda: ui.on_click(index = ui.card5,\
                             cards = cards, cardex = cards.c5, disc_class = td))
    ui.card6.clicked.connect(lambda: ui.on_click(index = ui.card6,\
                             cards = cards, cardex = cards.c6, disc_class = td))
    ui.card7.clicked.connect(lambda: ui.on_click(index = ui.card7,\
                             cards = cards, cardex = cards.c7, disc_class = td))
    ui.card8.clicked.connect(lambda: ui.on_click(index = ui.card8,\
                             cards = cards, cardex = cards.c8, disc_class = td))
    ui.card9.clicked.connect(lambda: ui.on_click(index = ui.card9,\
                             cards = cards, cardex = cards.c9, disc_class = td))
    ui.card10.clicked.connect(lambda: ui.on_click(index = ui.card10,\
                            cards = cards, cardex = cards.c10, disc_class = td))
    ui.card11.clicked.connect(lambda: ui.on_click(index = ui.card11,\
                            cards = cards, cardex = cards.c11, disc_class = td))
    ui.card12.clicked.connect(lambda: ui.on_click(index = ui.card12,\
                            cards = cards, cardex = cards.c12, disc_class = td))
    ui.card13.clicked.connect(lambda: ui.on_click(index = ui.card13,\
                            cards = cards, cardex = cards.c13, disc_class = td))
    sys.exit(app.exec_())

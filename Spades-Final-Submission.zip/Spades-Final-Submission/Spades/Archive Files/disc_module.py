from spades_functions import *
from spades_cards import Cards
from spades_discard import Discard

def comp_discards(cards, discard):
    if cards.turn[0] == 1:
        return

    wrap = discard.player_disc(cards.turn[0], 1, cards.spades_break)
    if cards.turn[0] == 2:
        cards.p2 = wrap[0]
        cards.p2disc = wrap[1]
        cards.spades_break = wrap[2]
        cards.p2_discs.append(wrap[3])
        cards.set_suit = wrap[4]

        wrap = discard.player_disc(cards.turn[1], 2, cards.spades_break)
        cards.p3 = wrap[0]
        cards.p3disc = wrap[1]
        cards.spades_break = wrap[2]
        cards.p3_discs.append(wrap[3])
        cards.set_suit = wrap[4]

        wrap = discard.player_disc(cards.turn[2], 3, cards.spades_break)
        cards.p4 = wrap[0]
        cards.p4disc = wrap[1]
        cards.spades_break = wrap[2]
        cards.p4_discs.append(wrap[3])
        cards.set_suit = wrap[4]

        return cards.p2, cards.p2disc, cards.p2_discs, cards.p3, cards.p3disc,\
               cards.p3_discs, cards.p4, cards.p4disc, cards.p4_discs,\
               cards.set_suit, cards.spades_break
    elif cards.turn[0] == 3:
        wrap = discard.player_disc(cards.turn[0], 1, cards.spades_break)
        cards.p3 = wrap[0]
        cards.p3disc = wrap[1]
        cards.spades_break = wrap[2]
        cards.p3_discs.append(wrap[3])
        cards.set_suit = wrap[4]

        wrap = discard.player_disc(cards.turn[1], 2, cards.spades_break)
        cards.p4 = wrap[0]
        cards.p4disc = wrap[1]
        cards.spades_break = wrap[2]
        cards.p4_discs.append(wrap[3])
        cards.set_suit = wrap[4]

        return cards.p3, cards.p3disc, cards.p3_discs, cards.p4, cards.p4disc,\
               cards.p4_discs, cards.set_suit, cards.spades_break
    elif cards.turn[0] == 4:
        wrap = discard.player_disc(cards.turn[0], 1, cards.spades_break)
        cards.p4 = wrap[0]
        cards.p4disc = wrap[1]
        cards.spades_break = wrap[2]
        cards.p4_discs.append(wrap[3])
        cards.set_suit = wrap[4]
        return  cards.p4, cards.p4disc, cards.p4_discs, cards.set_suit, \
                cards.spades_break

tc = Cards()
td = Discard()
tc.turn = [2,3,4,1]
print(tc.p2disc)
print(tc.p3disc)
print(tc.p4disc)
comp_discards(tc, td)
print(tc.p2disc)
print(tc.p3disc)
print(tc.p4disc)

"""
This script is a comit
"""
from spades_functions import *
import pandas as pd
import math
import random

class Cards:
    """
    This class creates various attributes for a round of spades,
    and establishes the object frame work necessary to be used in logic
    and other facets of a
    game of spades
    """

    def __init__(self):


        self.p1_discs = [] # These will help dictate
        self.p2_discs = [] # a round by anchoring
        self.p3_discs = [] # to self.turn, and automated
        self.p4_discs = [] # CPU discards

        self.game_len = (self.p1_discs + self.p2_discs + self.p3_discs\
                            + self.p4_discs)

        self.started = 0

        self.round = 1

        self.deck = self.set_deck()

        self.p1disc = None
        self.p2disc = None
        self.p3disc = None
        self.p4disc = None

        self.winner = None
        self.game_winner = None

        self.highs = ["Jack","Queen","King","Ace"]
        self.mids = [7,8,9,10]
        self.lows = [2,3,4,5,6]

        self.spades_break = 1
        self.set_suit = None

        self.turn = self.deck[0]
        p1 = self.deck[1]
        self.p1 = p1
        self.c1 = p1[0]
        self.c2 = p1[1]
        self.c3 = p1[2]
        self.c4 = p1[3]
        self.c5 = p1[4]
        self.c6 = p1[5]
        self.c7 = p1[6]
        self.c8 = p1[7]
        self.c9 = p1[8]
        self.c10 = p1[9]
        self.c11 = p1[10]
        self.c12 = p1[11]
        self.c13 = p1[12]

        # We use a randomly generated shell of cards for a user's hand
        # and then create the user, and self.p1 becomes the cardObject owner
        # but the cards must be moved to the discards containers

        self.p1_bid = int(self.deck[2])

        self.p2 = self.deck[3]
        self.p2_bid = int(self.deck[4])


        self.p3 = self.deck[5]
        self.p3_bid = int(self.deck[6])


        self.p4 = self.deck[7]
        self.p4_bid = int(self.deck[8])

        self.team1 = self.p1, self.p3
        self.team2 = self.p2, self.p4

        self.team1_bids = self.p1_bid, self.p3_bid
        self.team2_bids = self.p2_bid, self.p4_bid

        self.suits = {"Hearts", "Clubs", "Diamonds", "Spades"}

        self.score_frame = pd.DataFrame({"Bids":[self.p1_bid, self.p2_bid, \
                    self.p3_bid, self.p4_bid,"nan"],"Wins":[0, 0, 0, 0, 0],\
                    "Bags":[0, 0, 0, 0, 0], "Score":[0,0,0,0,0], \
                    "Rd1":[0,0,0,0,0], "Rd2":[0,0,0,0,0], "Rd3":[0,0,0,0,0],\
                    "Rd4":[0,0,0,0,0], "Rd5":[0,0,0,0,0], "Rd6":[0,0,0,0,0],\
                    "Rd7":[0,0,0,0,0], "Rd8":[0,0,0,0,0], "Rd9":[0,0,0,0,0],\
                    "Rd10":[0,0,0,0,0],"Rd11":[0,0,0,0,0], "Rd13":[0,0,0,0,0]},
                    index = ["Player 1", "Player 2", "Player 3", "Player 4",\
                    "Winner"])

    def set_deck(self):
        self.deck = initialize_spades(spades_deal(shuffled(spades_deck())))
        return self.deck
    def hearts(self, p_hand):
        """ This method counts hearts, and will help in logic for discards"""
        count = counter(p_hand)
        return count[0]

    def clubs(self, p_hand):
        """ This method counts clubs, and will help in logic for discards"""
        count = counter(p_hand)
        return count[1]

    def diamonds(self, p_hand):
        """ This method counts diamonds, and will help in logic for discards"""
        count = counter(p_hand)
        return count[2]

    def spades(self, p_hand):
        """ This method counts spades, and will help in logic for discards"""
        count = counter(p_hand)
        return count[3]

    def max_suit(self, p_hand):
        """
        This method determines the suit with the most cards in a given hand
        """
        hearts = self.hearts(p_hand)
        clubs = self.clubs(p_hand)
        diamonds = self.diamonds(p_hand)
        spades = self.spades(p_hand)
        if(hearts >= clubs and hearts >= diamonds and hearts >= spades):
            return "Hearts"
        elif(clubs >= hearts and clubs >= diamonds and clubs >= spades):
            return "Clubs"
        elif(diamonds >= hearts and diamonds >= clubs and diamonds >= spades):
            return "Diamonds"
        elif(spades >= hearts and spades >= clubs and spades >= diamonds):
            return "Spades"

    def min_suit(self, p_hand):
        hearts = self.hearts(p_hand)
        clubs = self.clubs(p_hand)
        diamonds = self.diamonds(p_hand)
        spades = self.spades(p_hand)
        """
        This method determines the suit with the least cards in a given hand
        """
        if(hearts <= clubs and hearts <= diamonds and hearts <= spades):
            return "Hearts"
        elif(clubs <= hearts and clubs <= diamonds and clubs <= spades):
            return "Clubs"
        elif(diamonds <= hearts and diamonds <= clubs and diamonds <= spades):
            return "Diamonds"
        elif(spades <= hearts and spades <= clubs and spades <= diamonds):
            return "Spades"

from spades_functions import *
from spades_cards import Cards
import pandas as pd
import numpy as np
import math
import random

class Discard(Cards):
    def __init__(self):
        Cards.__init__(self)

    def remove_card(self, player, card):
        for i in player:
            if i == card:
                return player.remove(card)

    def flog(self, cards, p_hand, p_bid, mate_bid, spades_break):
        """ This method is to be used in determining an automated discard
        for a player taking the first turn

        Args:
            p_hand(list of tuples) - The hand of the player discarding
            p_bid(int) - The bid of the player discarding
            min_suit(str) - The suit with the least cards
            max_suit(str) - The suit with the most cards
            spades_break(int) - Either a 1 or 0, used for boolean purposes

        Returns:
            p_hand(list of tuples) - The cards in a player's hand with
                                     the discard removed
            discard(tuple) - An enum_erator, face value, and suit for the
                             card discarded
            spades_break(int) - Either a 1 or 0, used for boolean purposes
        """
        min_suit = self.min_suit(p_hand)
        max_suit = self.max_suit(p_hand)
        while cards.spades_break == 1:
            if p_bid == 0:
                for enum_, face, suit in p_hand:
                    if (suit != "Spades"
                    and face in cards.lows
                    or face in cards.mids):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == max_suit and max_suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                    elif face in cards.lows and suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if (face in cards.mids
                    or face in cards.lows
                    and suit != "Spades"):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if face != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

            elif p_bid != 0:
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if face in cards.highs and suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if (suit != "Spades"
                    and face in cards.lows
                    or face in cards.mids
                    or suit == min_suit):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
            for enum_, face, suit in p_hand:
                if suit != "Spades":
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 1
            for enum_, face, suit in p_hand:
                if suit == "Spades":
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0

        while cards.spades_break == 0:
            if p_bid == 0:
                for enum_, face, suit in p_hand:
                    if suit == min_suit and face in cards.lows:

                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                    elif suit == max_suit and face not in cards.highs:

                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                        for enum_, face, suit in p_hand:
                            discard = (enum_, face, suit)
                            p_hand.remove(discard)
                            return p_hand, discard, 0

            if p_bid != 0:
                for enum_, face, suit in p_hand:
                    if suit == max_suit and face in cards.highs:

                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                    elif suit == min_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0


    def slog(self, cards, p_hand, p_bid, mate_bid, first_disc, spades_break):
        """ This method is to be used in determining an automated discard
        for a player taking the second turn

        Args:
            p_hand(list of tuples) - The hand of the player discarding
            p_bid(int) - The bid of the player discarding
            mate_bid(int) - The bid of the teammate for the player discarding
            first_disc(tuple) - The card discarded in the first turn
            spades_break(int) - Either a 1 or 0, used for boolean purposes

        Returns:
            p_hand(list of tuples) - The cards in a player's hand with the
                                     discard removed
            discard(tuple) - An enum_erator, face value, and suit for the card
                             discarded
            spades_break(int) - Either a 1 or 0, used for boolean purposes
        """
        set_suit = cards.set_suit
        while cards.spades_break == 1:
            if p_bid != 0 and mate_bid == 0:
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if (suit == set_suit and enum_ > first_disc[0]):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                    elif suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != set_suit and suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

            elif p_bid == 0:
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ < first_disc[0]:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if (suit != "Spades"
                    and suit == self.min_suit(p_hand)
                    or suit == self.max_suit(p_hand)):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if (suit != "Spades"):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != set_suit and suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
            for enum_, face, suit in p_hand:
                if suit == set_suit:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 1
            for enum_, face, suit in p_hand:
                if suit != set_suit and suit != "Spades":
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 1
            for enum_, face, suit in p_hand:
                if suit == "Spades":
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0
        while cards.spades_break == 0:
            if p_bid != 0:
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ > first_disc[0]:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in sorted(p_hand):
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
                for enum_, face, suit in sorted(p_hand):
                    if suit != set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == "Spades" and enum_ > first_disc[0]:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
                for enum_, face, suit in p_hand:
                    if suit != set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

            elif p_bid == 0:
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ < first_disc[0]:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    if suit != set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
            for enum_, face, suit in p_hand:
                if suit == set_suit:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0
            for enum_, face, suit in p_hand:
                if suit != set_suit:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0

    def tlog(self, cards, p_hand, p_bid, mate_bid, mate_disc, opp_disc, spades_break):
        """ This method is to be used in determining an automated discard
        for a player taking the third turn

        Args:
            p_hand(list of tuples) - The hand of the player discarding
            p_bid(int) - The bid of the player discarding
            mate_bid(int) - The bid of the teammate for the player discarding
            mate_disc(tuple) - The card discarded in the first turn
            opp_disc(tuble) - The card discarded in the second turn
            spades_break(int) - Either a 1 or 0, used for boolean purposes

        Returns:
            p_hand(list of tuples) - The cards in a player's hand with
                                     the discard removed
            discard(tuple) - An enum_erator, face value, and suit for
                             the card discarded
            spades_break(int) - Either a 1 or 0, used for boolean purposes
        """

        mate_enum_ = mate_disc[0]
        set_suit = cards.set_suit

        opp_suit = opp_disc[2]
        opp_enum_ = opp_disc[0]

        while cards.spades_break == 1:
            if (p_bid != 0
            and mate_enum_ < opp_enum_
            and set_suit == opp_suit):
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ > opp_enum_:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != set_suit and suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != set_suit and suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 1

            elif p_bid != 0 and mate_enum_ > opp_enum_:
                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != set_suit and suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != set_suit and suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

            elif p_bid == 0:
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if (suit == set_suit
                    and enum_ < mate_enum_
                    or enum_ < opp_enum_):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != set_suit and suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != set_suit and suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
            for enum_, face, suit in p_hand:
                if suit == set_suit:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 1
            for enum_, face, suit in p_hand:
                if suit != set_suit and suit != "Spades":
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 1
            for enum_, face, suit in p_hand:
                if suit != set_suit and suit == "Spades":
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0
        while cards.spades_break == 0:
            if (p_bid != 0
            and mate_enum_ < opp_enum_
            and set_suit == opp_suit):
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ > opp_enum_:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
                for enum_, face, suit in p_hand:
                    if suit != set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
            elif (p_bid != 0
                 and mate_enum_ < opp_enum_
                 and opp_suit != set_suit):
                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
                for enum_, face, suit in p_hand:
                    if suit != set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

            elif p_bid != 0 and mate_enum_ > opp_enum_:
                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0

            elif p_bid == 0:
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if (suit == set_suit
                    and enum_ < opp_enum_
                    or enum_ < mate_enum_):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0

            for enum_, face, suit in p_hand:
                discard = (enum_, face, suit)
                p_hand.remove(discard)
                return p_hand, discard, 0

    def four_log(self, cards, p_hand, p_bid, mate_bid, mate_disc, opp_disc, opp2_disc,\
                 spades_break):
        """ This method is to be used in determining an automated discard
        for a player taking the third turn

        Args:
            p_hand(list of tuples) - The hand of the player discarding
            p_bid(int) - The bid of the player discarding
            mate_bid(int) - The bid of the teammate for the player discarding
            mate_disc(tuple) - The card discarded in the first turn
            opp_disc(tuble) - The card discarded in the second turn
            spades_break(int) - Either a 1 or 0, used for boolean purposes

        Returns:
            p_hand(list of tuples) - The cards in a player's hand with
                                     the discard removed
            discard(tuple) - An enum_erator, face value, and suit for the
                             card discarded
            spades_break(int) - Either a 1 or 0, used for boolean purposes
        """
        set_suit = cards.set_suit
        mate_suit = mate_disc[2]
        mate_enum_ = mate_disc[0]

        opp_enum_ = opp_disc[0]
        opp2_suit = opp2_disc[2]
        opp2_enum_ = opp2_disc[0]

        while cards.spades_break == 1:
            if (p_bid != 0
            and mate_enum_ < opp_enum_
            or mate_enum_ < opp2_enum_):
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if (suit == set_suit
                    and enum_ > opp_enum_
                    and enum_ > opp2_enum_) :
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if (suit == set_suit
                    and enum_ < opp_enum_
                    and enum_ < opp2_enum_):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != set_suit and suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != set_suit and suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0


            elif p_bid != 0:
                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != set_suit and suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != set_suit and suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

            elif (p_bid != 0
            and mate_enum_ > opp_enum_
            and mate_enum_ > opp_enum_
            or mate_suit == set_suit):
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ < mate_enum_:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit != set_suit and suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit != set_suit and suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0


            elif p_bid == 0:
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if (suit == set_suit
                    and (enum_ < opp_enum_
                    or enum_ < mate_enum_
                    or enum_ < opp2_enum_)):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != set_suit and suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 1
                for enum_, face, suit in p_hand:
                    if suit != set_suit and suit == "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
            for enum_, face, suit in p_hand:
                if suit == set_suit:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 1
            for enum_, face, suit in p_hand:
                if suit != set_suit and suit != "Spades":
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 1
            for enum_, face, suit in p_hand:
                if suit != set_suit and suit == "Spades":
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0
        while cards.spades_break == 0:
            if (p_bid != 0
            and mate_enum_ < opp_enum_
            or mate_enum_ < opp2_enum_):

                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if suit == set_suit and enum_ > opp_enum_:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0

            elif (p_bid != 0
            and mate_enum_ > opp_enum_
            and mate_enum_ > opp2_enum_):

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0

            elif p_bid == 0:
                for enum_, face, suit in sorted(p_hand, reverse = True):
                    if (suit == set_suit
                    and enum_ < opp_enum_
                    or enum_ < mate_enum_
                    or enum_ < opp2_enum_):
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    if suit == set_suit:
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0

                for enum_, face, suit in p_hand:
                    if suit != "Spades":
                        discard = (enum_, face, suit)
                        p_hand.remove(discard)
                        return p_hand, discard, 0
                for enum_, face, suit in p_hand:
                    discard = (enum_, face, suit)
                    p_hand.remove(discard)
                    return p_hand, discard, 0

            for enum_, face, suit in p_hand:
                discard = (enum_, face, suit)
                p_hand.remove(discard)
                return p_hand, discard, 0

    def player_disc(self, player, turn, cards):
        """
        This method is used to generate a discard for a player based on the
        turn they are taking

        Args:
            player(int) - The number of the player whose turn it is
            turn(int) - The number in the order the player is discarding
            spades_break(1/0) - Boolean value used to indicate when Spades are
                                eligible

        Returns:
            p_hand(list of tuples) - The cards left in a player's hand
            p_disc(tuple) - The card which the player discarded
            spades_break(1/0) - Used for boolean purposes
            set_suit - The suit used in determining a winner of 4 discards
        """
        if player == 2 and turn == 1:
            bund1 = self.flog(cards, cards.p2, cards.p2_bid, cards.p4_bid, cards.spades_break)
            cards.p2 = bund1[0]
            cards.p2disc = bund1[1]
            cards.spades_break = bund1[2]
            cards.p2_discs.append(cards.p2disc)
            cards.set_suit = bund1[1][2]
            return cards.p2, cards.p2disc, cards.spades_break,\
                   cards.p2_discs, cards.set_suit
        elif player == 2 and turn == 2:
            bund = self.slog(cards, cards.p2, cards.p2_bid, cards.p4_bid, cards.p1disc,\
                             cards.spades_break)
            cards.p2 = bund[0]
            cards.p2disc = bund[1]
            cards.spades_break = bund[2]
            cards.p2_discs.append(cards.p2disc)
            cards.set_suit = cards.set_suit
            return cards.p2, cards.p2disc, cards.spades_break,\
                   cards.p2_discs, cards.set_suit
        elif player == 2 and turn == 3:
            bund = self.tlog(cards, cards.p2, cards.p2_bid, cards.p4_bid, cards.p4disc, \
                        cards.p1disc, cards.spades_break)
            cards.p2 = bund[0]
            cards.p2disc = bund[1]
            cards.spades_break = bund[2]
            cards.p2_discs.append(cards.p2disc)
            cards.set_suit = cards.set_suit
            return cards.p2, cards.p2disc, cards.spades_break,\
                   cards.p2_discs, cards.set_suit
        elif player == 2 and turn == 4:
            bund = self.four_log(cards, cards.p2, cards.p2_bid, cards.p4_bid, cards.p4disc, \
                        cards.p1disc, cards.p3disc, cards.spades_break)
            cards.p2 = bund[0]
            cards.p2disc = bund[1]
            cards.spades_break = bund[2]
            cards.p2_discs.append(cards.p2disc)
            cards.set_suit = cards.set_suit
            return cards.p2, cards.p2disc, cards.spades_break,\
                   cards.p2_discs, cards.set_suit
        elif player == 3 and turn == 1:
            bund = self.flog(cards, cards.p3, cards.p3_bid, cards.p1_bid, cards.spades_break)
            cards.p3 = bund[0]
            cards.p3disc = bund[1]
            cards.spades_break = bund[2]
            cards.p3_discs.append(cards.p3disc)
            cards.set_suit = bund[1][2]
            return cards.p3, cards.p3disc, cards.spades_break,\
                   cards.p3_discs, cards.set_suit
        elif player == 3 and turn == 2:
            bund = self.slog(cards, cards.p3, cards.p3_bid, cards.p1_bid, cards.p2disc,\
                             cards.spades_break)
            cards.p3 = bund[0]
            cards.p3disc = bund[1]
            cards.spades_break = bund[2]
            cards.p3_discs.append(cards.p3disc)
            cards.set_suit = cards.set_suit
            return cards.p3, cards.p3disc, cards.spades_break,\
                   cards.p3_discs, cards.set_suit
        elif player == 3 and turn == 3:
            bund = self.tlog(cards, cards.p3, cards.p3_bid, cards.p1_bid, cards.p1disc, \
                        cards.p2disc, cards.spades_break)
            cards.p3 = bund[0]
            cards.p3disc = bund[1]
            cards.spades_break = bund[2]
            cards.p3_discs.append(cards.p3disc)
            cards.set_suit = cards.set_suit
            return cards.p3, cards.p3disc, cards.spades_break,\
                   cards.p3_discs, cards.set_suit
        elif player == 3 and turn == 4:
            bund = self.four_log(cards, cards.p3, cards.p3_bid, cards.p1_bid, cards.p1disc, \
                        cards.p4disc, cards.p2disc, cards.spades_break)
            cards.p3 = bund[0]
            cards.p3disc = bund[1]
            cards.spades_break = bund[2]
            cards.p3_discs.append(cards.p3disc)
            cards.set_suit = cards.set_suit
            return cards.p3, cards.p3disc, cards.spades_break,\
                   cards.p3_discs, cards.set_suit

        elif player == 4 and turn == 1:
            bund = self.flog(cards, cards.p4, cards.p4_bid, cards.p2_bid, cards.spades_break)
            cards.p4 = bund[0]
            cards.p4disc = bund[1]
            cards.spades_break = bund[2]
            cards.p4_discs.append(cards.p4disc)
            cards.set_suit = bund[1][2]
            return cards.p4, cards.p4disc, cards.spades_break,\
                   cards.p4_discs, cards.set_suit
        elif player == 4 and turn == 2:
            bund = self.slog(cards, cards.p4, cards.p4_bid, cards.p2_bid, cards.p3disc,\
                             cards.spades_break)
            cards.p4 = bund[0]
            cards.p4disc = bund[1]
            cards.spades_break = bund[2]
            cards.p4_discs.append(cards.p4disc)
            cards.set_suit = cards.set_suit
            return cards.p4, cards.p4disc, cards.spades_break,\
                   cards.p4_discs, cards.set_suit
        elif player == 4 and turn == 3:
            bund = self.tlog(cards, cards.p4, cards.p4_bid, cards.p2_bid, cards.p2disc, \
                        cards.p3disc, cards.spades_break)
            cards.p4 = bund[0]
            cards.p4disc = bund[1]
            cards.spades_break = bund[2]
            cards.p4_discs.append(cards.p4disc)
            cards.set_suit = cards.set_suit
            return cards.p4, cards.p4disc, cards.spades_break,\
                   cards.p4_discs, cards.set_suit
        elif player == 4 and turn == 4:
            bund = self.four_log(cards, cards.p4, cards.p4_bid, cards.p2_bid, cards.p2disc, \
                        cards.p1disc, cards.p3disc, cards.spades_break)
            cards.p4 = bund[0]
            cards.p4disc = bund[1]
            cards.spades_break = bund[2]
            cards.p4_discs.append(cards.p4disc)
            cards.set_suit = cards.set_suit
            return cards.p4, cards.p4disc, cards.spades_break,\
                   cards.p4_discs, cards.set_suit
    def comp_discards(self, cards):
        if cards.turn[0] == 1:
            return
        if cards.turn[0] == 2:
            wrap1 = self.player_disc(2, 1, cards)
            cards.p2 = wrap1[0]
            cards.p2disc = wrap1[1]
            cards.spades_break = wrap1[2]
            cards.p2_discs.append(wrap1[1])
            cards.set_suit = wrap1[4]

            wrap2 = self.player_disc(3, 2, cards)
            cards.p3 = wrap2[0]
            cards.p3disc = wrap2[1]
            cards.spades_break = wrap2[2]
            cards.p3_discs.append(wrap2[1])
            cards.set_suit = wrap2[4]

            wrap3 = self.player_disc(4, 3, cards)
            cards.p4 = wrap3[0]
            cards.p4disc = wrap3[1]
            cards.spades_break = wrap3[2]
            cards.p4_discs.append(wrap3[1])
            cards.set_suit = wrap3[4]

            return cards.p2, cards.p2disc, cards.p2_discs, cards.p3, cards.p3disc,\
                   cards.p3_discs, cards.p4, cards.p4disc, cards.p4_discs,\
                   cards.set_suit, cards.spades_break
        elif cards.turn[0] == 3:
            wrap1 = self.player_disc(3, 1, cards)
            cards.p3 = wrap1[0]
            cards.p3disc = wrap1[1]
            cards.spades_break = wrap1[2]
            cards.p3_discs.append(wrap1[1])
            cards.set_suit = wrap1[4]

            wrap2 = self.player_disc(4, 2, cards)
            cards.p4 = wrap2[0]
            cards.p4disc = wrap2[1]
            cards.spades_break = wrap2[2]
            cards.p4_discs.append(wrap2[1])
            cards.set_suit = wrap2[4]

            return cards.p3, cards.p3disc, cards.p3_discs, cards.p4, cards.p4disc,\
                   cards.p4_discs, cards.set_suit, cards.spades_break
        elif cards.turn[0] == 4:
            wrap1 = self.player_disc(4, 1, cards)
            cards.p4 = wrap1[0]
            cards.p4disc = wrap1[1]
            cards.spades_break = wrap1[2]
            cards.p4_discs.append(wrap1[1])
            cards.set_suit = wrap1[4]
            return  cards.p4, cards.p4disc, cards.p4_discs, cards.set_suit, \
                    cards.spades_break

    def after_user_disc(self, cards, p1disc):
        """ This function is used to automate discards for computer players,
            while accounting for the order of turns, and only returning discards
            up to the point of the users turn

            Args:
                cards(Class) - The cards class being used within a program
                discard(Class) - The Discard class used for logic in discards

            Returns:
                None - if class.turn[0] == 1

                UPDATED ATTRIBUTES FOR:
                cards.spades_break - NA
                cards.p2           - NA
                cards.p2disc       - NA
                cards.p2discs      - NA
                cards.p3           - if class.turn[0] == 1 or if class.turn[1] == 1
                cards.p3disc       - if class.turn[0] == 1 or if class.turn[1] == 1
                cards.p3discs      - if class.turn[0] == 1 or if class.turn[1] == 1
                cards.p4           - if class.turn[0] == 1
                cards.p4disc       - if class.turn[0] == 1
                cards.p4discs      - if class.turn[0] == 1

            Side effects - Alters variables within cards_class
        """
        if cards.spades_break == 1 and p1disc[2] == "Spades":
            p1_sp = 0
        if cards.spades_break == 1 and p1disc[2] != "Spades":
            p1_sp = 1
        if cards.spades_break == 0:
            p1_sp = 0

        if cards.turn[0] == 1:
            cards.p1disc = p1disc
            cards.p1_discs.append(p1disc)
            cards.set_suit = p1disc[2]
            cards.spades_break = p1_sp

            wrap = self.slog(cards, cards.p2, cards.p2_bid, cards.p4_bid, \
                             cards.p1disc, cards.spades_break)
            cards.p2 = wrap[0]
            cards.p2disc = wrap[1]
            cards.spades_break = wrap[2]
            cards.p2_discs.append(wrap[0])

            wrap = self.tlog(cards, cards.p3, cards.p3_bid, cards.p1_bid, cards.p1disc,\
                             cards.p2disc, cards.spades_break)
            cards.p3 = wrap[0]
            cards.p3disc = wrap[1]
            cards.spades_break = wrap[2]
            cards.p3_discs.append(wrap[0])

            wrap = self.four_log(cards, cards.p4, cards.p4_bid, cards.p2_bid, \
                                 cards.p2disc, cards.p1disc, cards.p3disc,\
                                 cards.spades_break)
            cards.p4 = wrap[0]
            cards.p4disc = wrap[1]
            cards.spades_break = wrap[2]
            cards.p4_discs.append(wrap[0])

            return cards.p1, cards.p1disc, cards.p1_discs,\
                   cards.p2, cards.p2disc, cards.p2_discs,\
                   cards.p3, cards.p3disc, cards.p3_discs,\
                   cards.p4, cards.p4disc, cards.p4_discs,\
                   cards.set_suit, cards.spades_break

        elif cards.turn[1] == 1:
            cards.p1disc = p1disc
            cards.p1_discs.append(p1disc)
            cards.spades_break = p1_sp
            wrap = self.tlog(cards, cards.p2, cards.p2_bid, cards.p4_bid, cards.p4disc,\
                             cards.p1disc, cards.spades_break)
            cards.p2 = wrap[0]
            cards.p2disc = wrap[1]
            cards.spades_break = wrap[2]
            cards.p2_discs.append(wrap[0])

            wrap = self.four_log(cards, cards.p3, cards.p3_bid, cards.p1_bid, \
                                 cards.p1disc, cards.p2disc, cards.p4disc,\
                                 cards.spades_break)
            cards.p3 = wrap[0]
            cards.p3disc = wrap[1]
            cards.spades_break = wrap[2]
            cards.p3_discs.append(wrap[0])

            return cards.p1, cards.p1disc, cards.p1_discs,\
                   cards.p2, cards.p2disc, cards.p2_discs,\
                   cards.p3, cards.p3disc, cards.p3_discs,\
                   cards.spades_break

        elif cards.turn[2] == 1:
            cards.p1disc = p1disc
            cards.p1_discs.append(p1disc)
            cards.spades_break = p1_sp
            wrap = self.four_log(cards, cards.p2, cards.p2_bid, cards.p4_bid, \
                                 cards.p4disc, cards.p1disc, cards.p3disc,\
                                 cards.spades_break)
            cards.p2 = wrap[0]
            cards.p2disc = wrap[1]
            cards.spades_break = wrap[2]
            cards.p2_discs.append(wrap[1])
            return  cards.p1, cards.p1disc, cards.p1_discs,\
                    cards.p2, cards.p2disc, cards.p2_discs,\
                    cards.spades_break

        elif cards.turn[3] == 1:
            cards.p1disc = p1disc
            cards.p1_discs.append(p1disc)
            cards.spades_break = p1_sp
            return cards.p1, cards.p1disc, cards.p1_discs,\
                   cards.spades_break
